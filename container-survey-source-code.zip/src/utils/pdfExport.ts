import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { SurveyRecord, SurveyTotals, UserProfile } from '../types';
import { todayStr, formatDateLabel } from './storage';

export async function exportReportToPdf(elementId: string, filenamePrefix = 'maharashtra-container-survey'): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error('Report element not found');
  }

  // Create canvas using html2canvas with scale: 2 for sharp vector/text quality
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: 1024,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.95);
  
  // Calculate A4 dimensions (mm)
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();
  
  const imgWidth = pdfWidth - 16; // 8mm margins
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 8; // top margin

  // First page
  pdf.addImage(imgData, 'JPEG', 8, position, imgWidth, imgHeight);
  heightLeft -= (pdfHeight - 16);

  // Subsequent pages if long report
  while (heightLeft > 0) {
    position = heightLeft - imgHeight + 8;
    pdf.addPage();
    pdf.addImage(imgData, 'JPEG', 8, position, imgWidth, imgHeight);
    heightLeft -= (pdfHeight - 16);
  }

  pdf.save(`${filenamePrefix}-${todayStr()}.pdf`);
}

export function getRiskLevel(hi: number, ci: number, bi: number) {
  const isHigh = hi >= 5 || ci >= 10 || bi >= 20;
  const isMedium = (hi >= 1 && hi < 5) || (ci >= 1 && ci < 10) || (bi >= 5 && bi < 20);
  
  if (isHigh) {
    return {
      text: 'अति-संवेदनशील / धोकादायक (High Risk)',
      color: '#BA2525',
      bgColor: '#FDE8E8',
      desc: 'त्वरित डास अळी निर्मूलन, धुरळणी व जनजागृती मोहीम राबवावी.',
    };
  }
  if (isMedium) {
    return {
      text: 'मध्यम / सावधानता पातळी (Moderate Alert)',
      color: '#B45309',
      bgColor: '#FEF3C7',
      desc: 'साप्ताहिक ड्राय डे (कोरडा दिवस) व अबेट उपचारांवर भर द्यावा.',
    };
  }
  return {
    text: 'नियंत्रणात / सुरक्षित (Low Risk)',
    color: '#107C41',
    bgColor: '#EAF7EE',
    desc: 'सध्या डास अळी प्रादुर्भाव नियंत्रणात आहे. नियमित तपासणी सुरू ठेवावी.',
  };
}
