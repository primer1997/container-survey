import { SurveyRecord, UserProfile, SurveyTotals } from '../types';

export const STORE_KEY = 'cs-records';
export const USERS_KEY = 'cs-users';
export const USER_SESSION_KEY = 'cs-current-user';

export function todayStr(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDateLabel(dateStr: string): string {
  try {
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('mr-IN', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function getHeaderDateMarathi(): string {
  try {
    return new Date().toLocaleDateString('mr-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return todayStr();
  }
}

export const DEFAULT_USERS: Record<string, UserProfile> = {
  'patya.mohite@gmail.com': {
    email: 'patya.mohite@gmail.com',
    password: 'password',
    name: 'पांडुरंग मोहिते',
    designation: 'आरोग्य सेवक / MPW',
    employeeId: 'MH-PHD-408',
    district: 'पुणे',
    taluka: 'हवेली',
    phc: 'प्रा.आ. केंद्र कोंढवा',
    subCenter: 'उपकेंद्र कोंडापूर',
    village: 'कोंडापूर',
    assignedVillages: ['कोंडापूर', 'येवलेवाडी', 'पिसोळी', 'मांगडेवाडी'],
    createdAt: '2026-01-10T10:00:00Z',
  },
  'anita.sutar@gmail.com': {
    email: 'anita.sutar@gmail.com',
    password: 'password',
    name: 'अनिता सुतार',
    designation: 'आरोग्य सेविका / ANM',
    employeeId: 'MH-PHD-512',
    district: 'पुणे',
    taluka: 'हवेली',
    phc: 'प्रा.आ. केंद्र वाघोली',
    subCenter: 'उपकेंद्र वाघोली',
    village: 'वाघोली',
    assignedVillages: ['वाघोली', 'बाकोरी', 'भावडी'],
    createdAt: '2026-01-15T11:00:00Z',
  },
  'sachin.gaikwad@gmail.com': {
    email: 'sachin.gaikwad@gmail.com',
    password: 'password',
    name: 'सचिन गायकवाड',
    designation: 'आरोग्य सहाय्यक / HA',
    employeeId: 'MH-PHD-305',
    district: 'पुणे',
    taluka: 'बारामती',
    phc: 'प्रा.आ. केंद्र माळेगाव',
    subCenter: 'उपकेंद्र पणदरे',
    village: 'पणदरे',
    assignedVillages: ['पणदरे', 'कोरोची', 'काऱ्हाटी', 'शिरवली'],
    createdAt: '2026-02-01T09:30:00Z',
  },
};

export function getAllUsers(): Record<string, UserProfile> {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (!raw) {
      localStorage.setItem(USERS_KEY, JSON.stringify(DEFAULT_USERS));
      return DEFAULT_USERS;
    }
    const parsed = JSON.parse(raw);
    return parsed && Object.keys(parsed).length > 0 ? parsed : DEFAULT_USERS;
  } catch {
    return DEFAULT_USERS;
  }
}

export function saveUsers(users: Record<string, UserProfile>): void {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed to save users', err);
  }
}

export function updateUserProfile(updated: UserProfile): Record<string, UserProfile> {
  const users = getAllUsers();
  users[updated.email] = {
    ...users[updated.email],
    ...updated,
  };
  saveUsers(users);

  // If current session is this user, sync session storage
  try {
    const sessionRaw = localStorage.getItem(USER_SESSION_KEY);
    if (sessionRaw) {
      const sessionUser = JSON.parse(sessionRaw);
      if (sessionUser?.email === updated.email) {
        localStorage.setItem(USER_SESSION_KEY, JSON.stringify(users[updated.email]));
      }
    }
  } catch (err) {
    console.error('Failed to sync session storage on user update', err);
  }

  return users;
}

export function deleteUserProfile(email: string): Record<string, UserProfile> {
  const users = getAllUsers();
  delete users[email];
  saveUsers(users);

  // If deleted user was active session, clear session
  try {
    const sessionRaw = localStorage.getItem(USER_SESSION_KEY);
    if (sessionRaw) {
      const sessionUser = JSON.parse(sessionRaw);
      if (sessionUser?.email === email) {
        localStorage.removeItem(USER_SESSION_KEY);
      }
    }
  } catch (err) {
    console.error('Failed to clear session on user delete', err);
  }

  return users;
}

export function getRecordsKey(currentUser: UserProfile | null): string {
  return currentUser ? `${STORE_KEY}:${currentUser.email}` : STORE_KEY;
}

export function formatIndianDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  return dateStr;
}

export function parseIndianDateToIso(indianDateStr: string): string {
  if (!indianDateStr) return '';
  const parts = indianDateStr.split('-');
  if (parts.length === 3 && parts[2].length === 4) {
    return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
  }
  return indianDateStr;
}

export function loadStoredRecords(currentUser: UserProfile | null): SurveyRecord[] {
  try {
    const key = getRecordsKey(currentUser);
    const raw = localStorage.getItem(key);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      // Remove any previously seeded practical/dummy records of peoples
      const realRecords = parsed.filter((r: SurveyRecord) => {
        if (!r || !r.id) return false;
        if (r.id.startsWith('rec-aug-') || r.id.startsWith('rec-sep-')) return false;
        return true;
      });
      if (realRecords.length !== parsed.length) {
        localStorage.setItem(key, JSON.stringify(realRecords));
      }
      return realRecords;
    }
    return [];
  } catch {
    return [];
  }
}

export function saveStoredRecords(currentUser: UserProfile | null, records: SurveyRecord[]): void {
  try {
    const key = getRecordsKey(currentUser);
    localStorage.setItem(key, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to persist records', err);
  }
}

export function calculateTotals(items: SurveyRecord[]): SurveyTotals {
  const totals = items.reduce(
    (acc, r) => {
      acc.housesInsp += r.housesInspected;
      acc.housesPos += r.housesPositive;
      acc.contInsp += r.containersInspected;
      acc.contPos += r.containersPositive;
      acc.contEmpty += r.containersEmptied;
      acc.abate += r.abate ? r.housesInspected : 0;
      return acc;
    },
    { housesInsp: 0, housesPos: 0, contInsp: 0, contPos: 0, contEmpty: 0, abate: 0 }
  );

  const hi = totals.housesInsp ? (totals.housesPos / totals.housesInsp) * 100 : 0;
  const ci = totals.contInsp ? (totals.contPos / totals.contInsp) * 100 : 0;
  const bi = totals.housesInsp ? (totals.contPos / totals.housesInsp) * 100 : 0;

  return {
    ...totals,
    hi,
    ci,
    bi,
  };
}

export function exportToCSV(items: SurveyRecord[]): void {
  const headers = [
    'तारीख',
    'गाव',
    'कुटुंबप्रमुखाचे नाव',
    'कुटुंबातील सदस्य',
    'तपासलेली घरे',
    'पॉझिटिव्ह घरे',
    'तपासलेले कंटेनर',
    'पॉझिटिव्ह कंटेनर',
    'रिकामे केलेले कंटेनर',
    'अॅबेट उपचार',
    'टिपा',
  ];

  const rows = items.map((r) => [
    r.date,
    r.village,
    r.head,
    r.members,
    r.housesInspected,
    r.housesPositive,
    r.containersInspected,
    r.containersPositive,
    r.containersEmptied,
    r.abate ? 'होय' : 'नाही',
    r.notes || '',
  ]);

  const csvContent = [headers, ...rows]
    .map((row) =>
      row
        .map((cell) => {
          const s = String(cell).replace(/"/g, '""');
          return /[",\n]/.test(s) ? `"${s}"` : s;
        })
        .join(',')
    )
    .join('\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `container-survey-${todayStr()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
