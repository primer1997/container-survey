export interface SurveyRecord {
  id: string;
  date: string; // YYYY-MM-DD
  village: string;
  subCenter?: string;
  phc?: string;
  head: string;
  members: number;
  housesInspected: number;
  housesPositive: number;
  containersInspected: number;
  containersPositive: number;
  containersEmptied: number;
  abate: boolean;
  notes?: string;
}

export interface UserProfile {
  email: string;
  password?: string;
  name: string;
  designation: string;
  employeeId: string;
  district?: string;
  taluka?: string;
  phc?: string;
  subCenter?: string;
  village?: string;
  assignedVillages?: string[];
  phone?: string;
  createdAt?: string;
}

export interface SurveyTotals {
  housesInsp: number;
  housesPos: number;
  contInsp: number;
  contPos: number;
  contEmpty: number;
  abate: number;
  hi: number; // House Index %
  ci: number; // Container Index %
  bi: number; // Breteau Index
}
