import React, { useState } from 'react';
import JSZip from 'jszip';

interface SourceCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SourceCodeModal: React.FC<SourceCodeModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const [activeFile, setActiveFile] = useState<string>('zip-download');
  const [isZipping, setIsZipping] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2500);
  };

  const handleDirectZipDownload = async () => {
    setIsZipping(true);
    try {
      // Try to download pre-generated full project zip
      const res = await fetch('/container-survey-source-code.zip');
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'container-survey-full-code.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setIsZipping(false);
        return;
      }
    } catch {
      // Fallback to in-browser JSZip generation
    }

    try {
      const zip = new JSZip();
      const srcFolder = zip.folder('src');
      const compFolder = srcFolder?.folder('components');
      const utilsFolder = srcFolder?.folder('utils');
      const dataFolder = srcFolder?.folder('data');

      // Add files
      zip.file('index.html', files['index.html']?.content || '');
      zip.file('package.json', files['package.json']?.content || '');
      zip.file('vite.config.ts', files['vite.config.ts']?.content || '');
      zip.file('README.md', files['apk-guide']?.content || '');

      srcFolder?.file('types.ts', files['types.ts']?.content || '');
      utilsFolder?.file('storage.ts', files['storage.ts']?.content || '');
      utilsFolder?.file('pdfExport.ts', files['pdfExport.ts']?.content || '');
      dataFolder?.file('healthJurisdiction.ts', files['healthJurisdiction.ts']?.content || '');

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'container-survey-full-code.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate zip', err);
      alert('ZIP तयार करण्यात त्रुटी आली. कृपया थेट लिंक वापरा.');
    } finally {
      setIsZipping(false);
    }
  };

  const handleDownloadStandaloneHtml = () => {
    const htmlContent = `<!DOCTYPE html>
<html lang="mr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>कंटेनर सर्वेक्षण (Container Survey)</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;800&family=Public+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Noto Sans Devanagari', 'Public Sans', sans-serif; -webkit-tap-highlight-color: transparent; }
  </style>
</head>
<body class="bg-[#F0F4F8] text-[#102A43] min-h-screen">
  <header class="sticky top-0 z-20 text-white shadow-md bg-[#0A2540] border-b border-[#163C66]">
    <div class="h-1 w-full bg-gradient-to-r from-[#FF9933] via-white to-[#138808]"></div>
    <div class="max-w-[620px] mx-auto px-4 py-3">
      <div class="flex items-center justify-between border-b border-[#163C66]/80 pb-2 mb-2">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-full bg-white/10 border border-[#FF9933]/60 flex items-center justify-center text-[#FF9933] font-black text-xs">MH</div>
          <div>
            <div class="text-[11px] font-bold text-[#FF9933] uppercase">महाराष्ट्र शासन • सार्वजनिक आरोग्य विभाग</div>
            <div class="text-[9.5px] text-[#9FB3C8]">राष्ट्रीय कीटकजन्य रोग नियंत्रण कार्यक्रम (NVBDCP)</div>
          </div>
        </div>
        <span class="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#EAF7EE] text-[#107C41]">सज्ज</span>
      </div>
      <h1 class="text-lg font-bold">कंटेनर सर्वेक्षण (Container Survey Offline App)</h1>
    </div>
  </header>

  <main class="max-w-[620px] mx-auto px-4 py-4">
    <div class="bg-white rounded-lg shadow-sm border border-[#D9E2EC] p-4 mb-4">
      <h2 class="text-base font-bold text-[#0F4C81] mb-2">नोंदणी फॉर्म</h2>
      <p class="text-xs text-gray-600 mb-3">हे एक स्टँडअलोन HTML फाईल आहे जी कोणत्याही Android WebView किंवा Website 2 APK बिल्डरमध्ये थेट चालते.</p>
      
      <div class="space-y-3 text-sm">
        <div>
          <label class="block font-medium mb-1">तारीख:</label>
          <input type="date" id="dateInput" class="w-full border rounded p-2 text-sm bg-[#F8FAFC]" />
        </div>
        <div>
          <label class="block font-medium mb-1">गाव:</label>
          <input type="text" id="villageInput" placeholder="गावाचे नाव" class="w-full border rounded p-2 text-sm" />
        </div>
        <div>
          <label class="block font-medium mb-1">कुटुंबप्रमुखाचे नाव:</label>
          <input type="text" id="headInput" placeholder="कुटुंबप्रमुख" class="w-full border rounded p-2 text-sm" />
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-medium mb-1">तपासलेले कंटेनर:</label>
            <input type="number" id="contInsp" value="4" min="0" class="w-full border rounded p-2 text-sm" />
          </div>
          <div>
            <label class="block font-medium mb-1">पॉझिटिव्ह कंटेनर:</label>
            <input type="number" id="contPos" value="0" min="0" class="w-full border rounded p-2 text-sm" />
          </div>
        </div>
        <button id="saveBtn" class="w-full bg-[#107C41] text-white font-bold py-2 rounded text-sm hover:bg-[#0E6251]">
          नोंद साठवा
        </button>
      </div>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-[#D9E2EC] p-4">
      <h2 class="text-base font-bold text-[#0F4C81] mb-2">साठवलेल्या नोंदी</h2>
      <div id="recordsList" class="text-xs space-y-2">नोंद उपलब्ध नाही.</div>
    </div>
  </main>

  <script>
    document.getElementById('dateInput').value = new Date().toISOString().split('T')[0];
    function getRecs() {
      try { return JSON.parse(localStorage.getItem('cs_standalone_recs') || '[]'); } catch { return []; }
    }
    function render() {
      const recs = getRecs();
      const list = document.getElementById('recordsList');
      if (!recs.length) {
        list.innerHTML = '<p class="text-gray-500">कोणतीही नोंद नाही.</p>';
        return;
      }
      list.innerHTML = recs.map(r => \`
        <div class="p-2 border rounded bg-gray-50 flex justify-between items-center">
          <div>
            <div class="font-bold">\${r.head} (\${r.village})</div>
            <div class="text-gray-500">\${r.date} | तपासलेले: \${r.contInsp} | पॉझिटिव्ह: \${r.contPos}</div>
          </div>
          <span class="\${r.contPos > 0 ? 'text-red-600 font-bold' : 'text-green-600 font-bold'}">
            \${r.contPos > 0 ? 'पॉझिटिव्ह' : 'निगेटिव्ह'}
          </span>
        </div>
      \`).join('');
    }
    document.getElementById('saveBtn').addEventListener('click', () => {
      const date = document.getElementById('dateInput').value;
      const village = document.getElementById('villageInput').value.trim() || 'कोंडापूर';
      const head = document.getElementById('headInput').value.trim() || 'नागरिक';
      const contInsp = parseInt(document.getElementById('contInsp').value) || 0;
      const contPos = parseInt(document.getElementById('contPos').value) || 0;
      const recs = getRecs();
      recs.unshift({ id: Date.now(), date, village, head, contInsp, contPos });
      localStorage.setItem('cs_standalone_recs', JSON.stringify(recs));
      render();
      alert('नोंद यशस्वीरित्या साठवली!');
    });
    render();
  </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'container-survey-standalone.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const files: Record<string, { label: string; language: string; content: string }> = {
    'zip-download': {
      label: '📦 संपूर्ण ZIP डाऊनलोड (Download ZIP)',
      language: 'markdown',
      content: `# 📦 कंटेनर सर्वेक्षण ॲप - संपूर्ण कोड ZIP फाईल डाऊनलोड

या प्रकल्पातील **प्रत्येक कोड फाईलची एकत्रित ZIP फाईल** तयार करण्यात आली आहे.

### 📥 फाईल कशी डाऊनलोड करावी?
वरील हिरव्या **"संपूर्ण ZIP डाऊनलोड करा"** बटणावर क्लिक करा, किंवा खालील थेट लिंकवर क्लिक करा:
👉 **[container-survey-source-code.zip डाऊनलोड करा](/container-survey-source-code.zip)**

---

### 📂 या ZIP फाईलमध्ये खालील सर्व फाईल्स समाविष्ट आहेत:
1. \`index.html\` - मुख्य HTML फाईल (PWA व मेटा डेटासह)
2. \`package.json\` - सर्व डिपेंडन्सीज व बिल्ड स्क्रिप्ट्स
3. \`vite.config.ts\` - Vite आणि PWA सर्विस वर्कर कॉन्फिगरेशन
4. \`tsconfig.json\` - TypeScript कॉन्फिगरेशन
5. \`src/types.ts\` - सर्व डेटा मॉडेल्स (SurveyRecord, UserProfile, SurveyTotals)
6. \`src/App.tsx\` - मुख्य ॲप्लिकेशन लॉजिक, स्टेट मॅनेजमेंट, टॅब्स
7. \`src/components/Header.tsx\` - त्रिरंगी शासकीय हेडर, कर्मचारी माहिती व स्थिती
8. \`src/components/EntryTab.tsx\` - नवीन सर्वेक्षण नोंदणी फॉर्म (स्टेपर बटणे, व्हॅलिडेशन)
9. \`src/components/RecordsTab.tsx\` - सर्व नोंदींची यादी, फिल्टर, सर्च, संपादन व डिलीट
10. \`src/components/SummaryTab.tsx\` - HI, CI, BI निर्देशांक, विश्लेषणात्मक आकडेवारी, CSV एक्सपोर्ट
11. \`src/components/PdfReportModal.tsx\` - महाराष्ट्र शासन अधिकृत PDF अहवाल जनरेटर
12. \`src/components/AuthModal.tsx\` - आरोग्य कर्मचारी प्रोफाइल, लॉगिन व कार्यक्षेत्र व्यवस्थापन
13. \`src/components/PWAInstallButton.tsx\` - 1-क्लिक Android PWA इन्स्टॉलर
14. \`src/utils/storage.ts\` - स्थानिक लोकल स्टोरेज, युजर्स, गणना सूत्रे
15. \`src/utils/pdfExport.ts\` - हाय-रिझोल्यूशन PDF एक्सपोर्ट व जोखीम विश्लेषण (Risk Level)
16. \`src/data/healthJurisdiction.ts\` - महाराष्ट्र आरोग्य कार्यक्षेत्र (जिल्हा, तालुका, PHC, उपकेंद्र, गावे)

---

### 🚀 ZIP फाईलवरून स्वतःच्या संगणकावर कसे चालवायचे?
1. डाऊनलोड झालेली \`container-survey-source-code.zip\` फाईल **Extract (Unzip)** करा.
2. टर्मिनल / CMD मध्ये त्या फोल्डरमध्ये जा:
   \`\`\`bash
   cd container-survey
   npm install
   npm run dev
   \`\`\`
3. ॲप \`http://localhost:3000\` वर लगेच सुरू होईल!`,
    },
    'apk-guide': {
      label: '📱 APK निर्मिती पद्धत (APK Guide)',
      language: 'markdown',
      content: `# 📱 कंटेनर सर्वेक्षण ॲप वरून Android APK फाईल बनवण्याच्या ३ सोप्या पद्धती:

---

### पद्धत १: Capacitor वापरून अधिकृत Android APK बनवणे (सर्वात शिफारस केलेली पद्धत)
हे React + Vite ॲप Capacitor द्वारे ५ मिनिटांत Android APK मध्ये रूपांतरित होते.

1. **प्रकल्प आपल्या कॉम्प्युटरवर डाऊनलोड करा** आणि टर्मिनल / CMD उघडा:
   \`\`\`bash
   # सर्व डिपेंडन्सीज इन्स्टॉल करा
   npm install

   # Capacitor इन्स्टॉल करा
   npm install @capacitor/core @capacitor/cli @capacitor/android

   # ॲप कॉन्फिगर करा
   npx cap init "कंटेनर सर्वेक्षण" "com.maharashtra.containersurvey"

   # ॲपचा प्रॉडक्शन बिल्ड तयार करा
   npm run build

   # अँड्रॉइड प्लॅटफॉर्म ॲड करा
   npx cap add android

   # सर्व कोड अँड्रॉइड फोल्डरमध्ये कॉपी करा
   npx cap sync
   \`\`\`

2. **Android Studio मध्ये प्रोजेक्ट उघडा**:
   \`\`\`bash
   npx cap open android
   \`\`\`

3. **Android Studio मध्ये APK बिल्ड करा**:
   - मेनूवर **Build** वर क्लिक करा.
   - **Build Bundle(s) / APK(s)** निवडा -> **Build APK(s)** वर क्लिक करा.
   - 2 मिनिटांत आपला \`app-debug.apk\` किंवा \`app-release.apk\` तयार होईल! हा APK कोणत्याही Android मोबाईलवर इन्स्टॉल करू शकता.

---

### पद्धत २: संगणकाशिवाय थेट मोबाईलवर ॲप इन्स्टॉल करणे (PWA तंत्रज्ञान)
हे ॲप आधीच 100% PWA (Progressive Web App) सक्षम आहे. APK बनवण्याची गरज न पडता मोबाईलवर थेट ॲप बनते:
1. हे ॲप आपल्या Android मोबाईलच्या **Google Chrome** मध्ये उघडा.
2. वरील **"ॲप इन्स्टॉल करा"** बटणावर क्लिक करा, किंवा Chrome च्या उजव्या कोपऱ्यातील तीन डॉट्स (⋮) दाबून **"Add to Home screen"** / **"Install app"** दाबा.
3. हे ॲप थेट फोनच्या ॲप ड्रॉवरमध्ये मूळ Android ॲपप्रमाणे सेव्ह होते आणि **इंटरनेटशिवाय (100% Offline)** चालते!

---

### पद्धत ३: Website 2 APK Builder / Web2APK टूल वापरणे
1. वर दिलेल्या **"स्टँडअलोन HTML डाऊनलोड करा"** बटणावर क्लिक करा.
2. संगणकावर **Website 2 APK Builder** (किंवा Android Studio WebView) सॉफ्टवेअर उघडा.
3. "Local HTML Website" पर्याय निवडा आणि डाऊनलोड केलेली फाईल सिलेक्ट करा.
4. "Generate APK" वर क्लिक करा. थेट \`.apk\` फाईल डाऊनलोड होईल!`,
    },
    'types.ts': {
      label: 'src/types.ts',
      language: 'typescript',
      content: `export interface SurveyRecord {
  id: string;
  date: string; // YYYY-MM-DD
  village: string;
  subCenter?: string;
  phc?: string;
  head: string;
  members: number;
  housesInspected: number;
  housesPositive: number;
  containersInspected: number;
  containersPositive: number;
  containersEmptied: number;
  abate: boolean;
  notes?: string;
}

export interface UserProfile {
  email: string;
  password?: string;
  name: string;
  designation: string;
  employeeId: string;
  district?: string;
  taluka?: string;
  phc?: string;
  subCenter?: string;
  village?: string;
  assignedVillages?: string[];
  phone?: string;
  createdAt?: string;
}

export interface SurveyTotals {
  housesInsp: number;
  housesPos: number;
  contInsp: number;
  contPos: number;
  contEmpty: number;
  abate: number;
  hi: number; // House Index %
  ci: number; // Container Index %
  bi: number; // Breteau Index
}`,
    },
    'storage.ts': {
      label: 'src/utils/storage.ts',
      language: 'typescript',
      content: `import { SurveyRecord, UserProfile, SurveyTotals } from '../types';

export const STORE_KEY = 'cs-records';
export const USERS_KEY = 'cs-users';
export const USER_SESSION_KEY = 'cs-current-user';

export function todayStr(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return \`\${year}-\${month}-\${day}\`;
}

export function formatDateLabel(dateStr: string): string {
  try {
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('mr-IN', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function getHeaderDateMarathi(): string {
  try {
    return new Date().toLocaleDateString('mr-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return todayStr();
  }
}

export function getRecordsKey(currentUser: UserProfile | null): string {
  return currentUser ? \`\${STORE_KEY}:\${currentUser.email}\` : STORE_KEY;
}

export function loadStoredRecords(currentUser: UserProfile | null): SurveyRecord[] {
  try {
    const key = getRecordsKey(currentUser);
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveStoredRecords(currentUser: UserProfile | null, records: SurveyRecord[]): void {
  try {
    const key = getRecordsKey(currentUser);
    localStorage.setItem(key, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to persist records', err);
  }
}

export function calculateTotals(items: SurveyRecord[]): SurveyTotals {
  const totals = items.reduce(
    (acc, r) => {
      acc.housesInsp += r.housesInspected;
      acc.housesPos += r.housesPositive;
      acc.contInsp += r.containersInspected;
      acc.contPos += r.containersPositive;
      acc.contEmpty += r.containersEmptied;
      acc.abate += r.abate ? r.housesInspected : 0;
      return acc;
    },
    { housesInsp: 0, housesPos: 0, contInsp: 0, contPos: 0, contEmpty: 0, abate: 0 }
  );

  const hi = totals.housesInsp ? (totals.housesPos / totals.housesInsp) * 100 : 0;
  const ci = totals.contInsp ? (totals.contPos / totals.contInsp) * 100 : 0;
  const bi = totals.housesInsp ? (totals.contPos / totals.housesInsp) * 100 : 0;

  return { ...totals, hi, ci, bi };
}`,
    },
    'pdfExport.ts': {
      label: 'src/utils/pdfExport.ts',
      language: 'typescript',
      content: `import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { SurveyRecord, SurveyTotals, UserProfile } from '../types';
import { todayStr, formatDateLabel } from './storage';

export async function exportReportToPdf(elementId: string, filenamePrefix = 'maharashtra-container-survey'): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error('Report element not found');
  }

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: 1024,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.95);
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();
  const imgWidth = pdfWidth - 16;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 8;

  pdf.addImage(imgData, 'JPEG', 8, position, imgWidth, imgHeight);
  heightLeft -= (pdfHeight - 16);

  while (heightLeft > 0) {
    position = heightLeft - imgHeight + 8;
    pdf.addPage();
    pdf.addImage(imgData, 'JPEG', 8, position, imgWidth, imgHeight);
    heightLeft -= (pdfHeight - 16);
  }

  pdf.save(\`\${filenamePrefix}-\${todayStr()}.pdf\`);
}`,
    },
    'index.html': {
      label: 'index.html',
      language: 'html',
      content: `<!doctype html>
<html lang="mr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>कंटेनर सर्वेक्षण</title>
    <meta name="theme-color" content="#0A2540" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="default" />
    <meta name="apple-mobile-web-app-title" content="कंटेनर सर्वेक्षण" />
    <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
    <link rel="icon" type="image/svg+xml" href="/icon.svg" />
    <meta name="description" content="सार्वजनिक आरोग्य विभाग, महाराष्ट्र शासन - कंटेनर सर्वेक्षण, डास अळी प्रतिबंधक तपासणी, HI, CI, BI इंडेक्स व शासकीय PDF अहवाल." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;800&family=Public+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`,
    },
    'package.json': {
      label: 'package.json',
      language: 'json',
      content: `{
  "name": "container-survey-app",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "jspdf": "^4.2.1",
    "jspdf-autotable": "^5.0.8",
    "jszip": "^3.10.1",
    "lucide-react": "^0.546.0",
    "react": "^19.0.1",
    "react-dom": "^19.0.1"
  },
  "devDependencies": {
    "@tailwindcss/vite": "^4.1.14",
    "@vitejs/plugin-react": "^5.0.4",
    "tailwindcss": "^4.1.14",
    "typescript": "~5.8.2",
    "vite": "^6.2.3",
    "vite-plugin-pwa": "^1.3.0"
  }
}`,
    },
    'vite.config.ts': {
      label: 'vite.config.ts',
      language: 'typescript',
      content: `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    tailwindcss(),
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'कंटेनर सर्वेक्षण',
        short_name: 'कंटेनर सर्व्हे',
        description: 'सार्वजनिक आरोग्य विभाग, महाराष्ट्र शासन - कंटेनर सर्वेक्षण व डास अळी प्रतिबंधक तपासणी प्रणाली',
        theme_color: '#0A2540',
        background_color: '#ffffff',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        icons: [
          { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' }
        ]
      }
    })
  ]
});`,
    },
    'healthJurisdiction.ts': {
      label: 'src/data/healthJurisdiction.ts',
      language: 'typescript',
      content: `export interface PhcData {
  name: string;
  subCenters: {
    name: string;
    villages: string[];
  }[];
}

export interface TalukaData {
  name: string;
  phcs: PhcData[];
}

export interface DistrictData {
  name: string;
  talukas: TalukaData[];
}

export const MAHARASHTRA_HEALTH_JURISDICTION: DistrictData[] = [
  {
    name: 'पुणे',
    talukas: [
      {
        name: 'हवेली',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र कोंढवा',
            subCenters: [
              { name: 'उपकेंद्र कोंडापूर', villages: ['कोंडापूर', 'येवलेवाडी', 'पिसोळी', 'मांगडेवाडी'] },
              { name: 'उपकेंद्र उंद्री', villages: ['उंद्री', 'हांडेवाडी', 'वडकी'] },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र वाघोली',
            subCenters: [
              { name: 'उपकेंद्र वाघोली', villages: ['वाघोली', 'बाकोरी', 'भावडी'] },
              { name: 'उपकेंद्र आव्हाळवाडी', villages: ['आव्हाळवाडी', 'लोणीकंद', 'पेरणे'] },
            ],
          },
        ],
      },
    ],
  },
];`,
    },
  };

  const currentFile = files[activeFile] || files['zip-download'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-none shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-[#E0DED6]">
        {/* MODAL HEADER */}
        <div className="bg-[#0A0A0A] text-white px-4 py-3 flex items-center justify-between border-b border-[#0A0A0A]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-none bg-[#0A0A0A]/20 border border-[#0A0A0A]/60 flex items-center justify-center text-[#0A0A0A] font-mono text-sm font-bold">
              📦
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">
                प्रकल्प संपूर्ण कोड ZIP फाईल व APK निर्मिती
              </h2>
              <p className="text-[11px] text-[#9A9A9A]">
                Download Total Source Code ZIP & APK Guide
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-none hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer text-lg"
          >
            ✕
          </button>
        </div>

        {/* TOP QUICK ACTIONS BAR WITH PROMINENT ZIP DOWNLOAD */}
        <div className="bg-[#F4F3EF] px-4 py-2.5 border-b border-[#E0DED6] flex items-center justify-between flex-wrap gap-2">
          <div className="text-xs text-[#0A0A0A] font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-none bg-[#1E7B34]"></span>
            <span>सर्व फाईल्सची ZIP फाईल तयार आहे:</span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {/* PRIMARY ZIP DOWNLOAD BUTTON */}
            <button
              type="button"
              onClick={handleDirectZipDownload}
              disabled={isZipping}
              className="bg-[#1E7B34] hover:bg-[#1E7B34] active:bg-[#1E7B34] text-white text-xs font-bold px-3.5 py-1.5 rounded-none flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="सर्व कोड फाईल्सची ZIP फाईल डाऊनलोड करा"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              <span>{isZipping ? 'ZIP तयार होत आहे...' : '📦 संपूर्ण ZIP डाऊनलोड करा'}</span>
            </button>

            {/* STANDALONE HTML BUTTON */}
            <button
              type="button"
              onClick={handleDownloadStandaloneHtml}
              className="bg-[#8A5A00] hover:bg-[#8A5A00] text-white text-xs font-bold px-3 py-1.5 rounded-none flex items-center gap-1 cursor-pointer"
              title="ऑफलाईन चालणारी स्टँडअलोन सिंगल HTML फाईल डाऊनलोड करा"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
              </svg>
              <span>सिंगल HTML</span>
            </button>

            {/* COPY BUTTON */}
            <button
              type="button"
              onClick={() => handleCopy(currentFile.content, activeFile)}
              className="bg-[#0A0A0A] hover:bg-[#0A0A0A] text-white text-xs font-bold px-3 py-1.5 rounded-none flex items-center gap-1.5 cursor-pointer"
            >
              {copied === activeFile ? (
                <>
                  <span>✓</span>
                  <span>कॉपी झाले!</span>
                </>
              ) : (
                <>
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                  </svg>
                  <span>कोड कॉपी करा</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* FILE SELECTOR TABS */}
        <div className="bg-[#E0DED6] px-3 py-1.5 flex gap-1.5 overflow-x-auto border-b border-[#9A9A9A] scrollbar-thin">
          {Object.entries(files).map(([key, item]) => (
            <button
              key={key}
              type="button"
              onClick={() => setActiveFile(key)}
              className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                activeFile === key
                  ? 'bg-white text-[#0A2540] font-bold shadow-xs border border-[#CBD5E1]'
                  : 'text-[#475569] hover:bg-white/60'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* CODE VIEWER AREA */}
        <div className="flex-1 p-3 bg-[#0A0A0A] overflow-y-auto">
          <pre className="text-[12px] font-mono text-[#E0DED6] whitespace-pre-wrap select-all leading-relaxed">
            <code>{currentFile.content}</code>
          </pre>
        </div>

        {/* FOOTER */}
        <div className="bg-white px-4 py-2.5 border-t border-[#E0DED6] flex items-center justify-between">
          <span className="text-[11px] text-gray-500">
            निवडलेली फाईल: <strong className="text-gray-700">{currentFile.label}</strong>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-[#6E6E6E] hover:bg-[#0A0A0A] text-white text-xs font-bold rounded-none cursor-pointer transition-colors"
          >
            बंद करा
          </button>
        </div>
      </div>
    </div>
  );
};
