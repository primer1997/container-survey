import React, { useState, useEffect, useMemo } from 'react';
import { UserProfile } from '../types';
import {
  getAllUsers,
  saveUsers,
  updateUserProfile,
  deleteUserProfile,
} from '../utils/storage';
import {
  getDistricts,
  getTalukas,
  getPhcs,
  getSubCenters,
  getVillages,
} from '../data/healthJurisdiction';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  currentUser?: UserProfile | null;
  initialMode?: 'login' | 'register' | 'edit';
  userToEdit?: UserProfile | null;
  onSuccess: (user: UserProfile) => void;
  onUserUpdated?: (user: UserProfile) => void;
  onUserDeleted?: (deletedEmail: string) => void;
  showToast: (msg: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  initialMode = 'login',
  userToEdit,
  onSuccess,
  onUserUpdated,
  onUserDeleted,
  showToast,
}) => {
  // Mode: 'login' | 'register' | 'edit'
  const [mode, setMode] = useState<'login' | 'register' | 'edit'>(initialMode);

  // All registered users in system
  const [registeredUsers, setRegisteredUsers] = useState<Record<string, UserProfile>>({});

  // Employee currently being edited or confirmed for deletion
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [confirmDeleteUser, setConfirmDeleteUser] = useState<UserProfile | null>(null);

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Form state - Personal & Designation
  const [regName, setRegName] = useState('');
  const [regDesignation, setRegDesignation] = useState('आरोग्य सेवक / MPW');
  const [regEmployeeId, setRegEmployeeId] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  // Form state - Administrative Jurisdiction
  const districtList = useMemo(() => getDistricts(), []);
  const [regDistrict, setRegDistrict] = useState('पुणे');
  const [customDistrict, setCustomDistrict] = useState('');

  const talukaList = useMemo(() => {
    if (regDistrict === '__OTHER__') return [];
    return getTalukas(regDistrict);
  }, [regDistrict]);
  const [regTaluka, setRegTaluka] = useState('हवेली');
  const [customTaluka, setCustomTaluka] = useState('');

  const phcList = useMemo(() => {
    if (regDistrict === '__OTHER__' || regTaluka === '__OTHER__') return [];
    return getPhcs(regDistrict, regTaluka);
  }, [regDistrict, regTaluka]);
  const [regPhc, setRegPhc] = useState('प्रा.आ. केंद्र कोंढवा');
  const [customPhc, setCustomPhc] = useState('');

  const subCenterList = useMemo(() => {
    if (
      regDistrict === '__OTHER__' ||
      regTaluka === '__OTHER__' ||
      regPhc === '__OTHER__'
    )
      return [];
    return getSubCenters(regDistrict, regTaluka, regPhc);
  }, [regDistrict, regTaluka, regPhc]);
  const [regSubCenter, setRegSubCenter] = useState('उपकेंद्र कोंडापूर');
  const [customSubCenter, setCustomSubCenter] = useState('');

  // Village options for selected sub-center
  const defaultVillagesForSubCenter = useMemo(() => {
    if (
      regDistrict === '__OTHER__' ||
      regTaluka === '__OTHER__' ||
      regPhc === '__OTHER__' ||
      regSubCenter === '__OTHER__'
    )
      return [];
    return getVillages(regDistrict, regTaluka, regPhc, regSubCenter);
  }, [regDistrict, regTaluka, regPhc, regSubCenter]);

  const [selectedVillages, setSelectedVillages] = useState<string[]>([
    'कोंडापूर',
    'येवलेवाडी',
    'पिसोळी',
  ]);
  const [regPrimaryVillage, setRegPrimaryVillage] = useState('कोंडापूर');
  const [newVillageInput, setNewVillageInput] = useState('');

  // Reload registered users when modal opens or initial mode updates
  useEffect(() => {
    if (isOpen) {
      const all = getAllUsers();
      setRegisteredUsers(all);
      setConfirmDeleteUser(null);

      if (userToEdit) {
        startEditUser(userToEdit);
      } else if (initialMode) {
        setMode(initialMode);
      }
    }
  }, [isOpen, initialMode, userToEdit]);

  // Update cascade handlers
  const handleDistrictChange = (dist: string) => {
    setRegDistrict(dist);
    if (dist === '__OTHER__') {
      setRegTaluka('__OTHER__');
      setRegPhc('__OTHER__');
      setRegSubCenter('__OTHER__');
      setSelectedVillages([]);
      setRegPrimaryVillage('');
    } else {
      const talukas = getTalukas(dist);
      const firstTaluka = talukas[0] || '__OTHER__';
      setRegTaluka(firstTaluka);
      handleTalukaChange(dist, firstTaluka);
    }
  };

  const handleTalukaChange = (dist: string, taluka: string) => {
    setRegTaluka(taluka);
    if (taluka === '__OTHER__') {
      setRegPhc('__OTHER__');
      setRegSubCenter('__OTHER__');
      setSelectedVillages([]);
      setRegPrimaryVillage('');
    } else {
      const phcs = getPhcs(dist, taluka);
      const firstPhc = phcs[0] || '__OTHER__';
      setRegPhc(firstPhc);
      handlePhcChange(dist, taluka, firstPhc);
    }
  };

  const handlePhcChange = (dist: string, taluka: string, phc: string) => {
    setRegPhc(phc);
    if (phc === '__OTHER__') {
      setRegSubCenter('__OTHER__');
      setSelectedVillages([]);
      setRegPrimaryVillage('');
    } else {
      const subCenters = getSubCenters(dist, taluka, phc);
      const firstSubCenter = subCenters[0] || '__OTHER__';
      setRegSubCenter(firstSubCenter);
      handleSubCenterChange(dist, taluka, phc, firstSubCenter);
    }
  };

  const handleSubCenterChange = (
    dist: string,
    taluka: string,
    phc: string,
    subCenter: string
  ) => {
    setRegSubCenter(subCenter);
    if (subCenter === '__OTHER__') {
      setSelectedVillages([]);
      setRegPrimaryVillage('');
    } else {
      const vList = getVillages(dist, taluka, phc, subCenter);
      setSelectedVillages(vList);
      setRegPrimaryVillage(vList[0] || '');
    }
  };

  // Add custom village to selectedVillages
  const handleAddCustomVillage = () => {
    const v = newVillageInput.trim();
    if (!v) return;
    if (!selectedVillages.includes(v)) {
      setSelectedVillages((prev) => [...prev, v]);
      if (!regPrimaryVillage) setRegPrimaryVillage(v);
    }
    setNewVillageInput('');
  };

  // Toggle village selection
  const toggleVillage = (v: string) => {
    if (selectedVillages.includes(v)) {
      const next = selectedVillages.filter((item) => item !== v);
      setSelectedVillages(next);
      if (regPrimaryVillage === v) {
        setRegPrimaryVillage(next[0] || '');
      }
    } else {
      setSelectedVillages((prev) => [...prev, v]);
      if (!regPrimaryVillage) setRegPrimaryVillage(v);
    }
  };

  // Reset form fields for brand new registration
  const resetRegisterFields = () => {
    setEditingUser(null);
    setRegName('');
    setRegDesignation('आरोग्य सेवक / MPW');
    setRegEmployeeId('');
    setRegPhone('');
    setRegEmail('');
    setRegPassword('');
    setRegDistrict('पुणे');
    setCustomDistrict('');
    setRegTaluka('हवेली');
    setCustomTaluka('');
    setRegPhc('प्रा.आ. केंद्र कोंढवा');
    setCustomPhc('');
    setRegSubCenter('उपकेंद्र कोंडापूर');
    setCustomSubCenter('');
    setSelectedVillages(['कोंडापूर', 'येवलेवाडी', 'पिसोळी']);
    setRegPrimaryVillage('कोंडापूर');
    setNewVillageInput('');
  };

  // Begin editing a specific employee
  const startEditUser = (u: UserProfile) => {
    setEditingUser(u);
    setRegName(u.name || '');
    setRegDesignation(u.designation || 'आरोग्य सेवक / MPW');
    setRegEmployeeId(u.employeeId || '');
    setRegPhone(u.phone || '');
    setRegEmail(u.email);
    setRegPassword(''); // Keep blank to retain existing

    // District setup
    const dist = u.district || 'पुणे';
    if (districtList.includes(dist)) {
      setRegDistrict(dist);
      setCustomDistrict('');
    } else {
      setRegDistrict('__OTHER__');
      setCustomDistrict(dist);
    }

    // Taluka setup
    const tList = getTalukas(dist);
    const tal = u.taluka || '';
    if (tList.includes(tal)) {
      setRegTaluka(tal);
      setCustomTaluka('');
    } else {
      setRegTaluka('__OTHER__');
      setCustomTaluka(tal);
    }

    // PHC setup
    const pList = getPhcs(dist, tal);
    const phcVal = u.phc || '';
    if (pList.includes(phcVal)) {
      setRegPhc(phcVal);
      setCustomPhc('');
    } else {
      setRegPhc('__OTHER__');
      setCustomPhc(phcVal);
    }

    // Sub-center setup
    const sList = getSubCenters(dist, tal, phcVal);
    const subVal = u.subCenter || '';
    if (sList.includes(subVal)) {
      setRegSubCenter(subVal);
      setCustomSubCenter('');
    } else {
      setRegSubCenter('__OTHER__');
      setCustomSubCenter(subVal);
    }

    // Village setup
    const assigned =
      u.assignedVillages && u.assignedVillages.length > 0
        ? u.assignedVillages
        : u.village
        ? [u.village]
        : ['कोंडापूर'];
    setSelectedVillages(assigned);
    setRegPrimaryVillage(u.village || assigned[0] || '');
    setNewVillageInput('');

    setMode('edit');
  };

  if (!isOpen) return null;

  // Resolve final effective names
  const effectiveDistrict =
    regDistrict === '__OTHER__' ? customDistrict.trim() : regDistrict;
  const effectiveTaluka =
    regTaluka === '__OTHER__' ? customTaluka.trim() : regTaluka;
  const effectivePhc = regPhc === '__OTHER__' ? customPhc.trim() : regPhc;
  const effectiveSubCenter =
    regSubCenter === '__OTHER__' ? customSubCenter.trim() : regSubCenter;
  const effectivePrimaryVillage = regPrimaryVillage.trim();

  // Handle Login submission
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const email = loginEmail.trim();
    const password = loginPassword;

    if (!email) {
      showToast('कृपया ईमेल आयडी टाका');
      return;
    }

    const users = getAllUsers();
    const user = users[email];
    if (!user) {
      // Allow demo login
      if (email && (password.length >= 4 || !password)) {
        const demoUser: UserProfile = {
          email,
          name: email.split('@')[0],
          designation: 'आरोग्य सेवक / MPW',
          employeeId: 'PHD-MH-01',
          district: 'पुणे',
          taluka: 'हवेली',
          phc: 'प्रा.आ. केंद्र कोंढवा',
          subCenter: 'उपकेंद्र कोंडापूर',
          village: 'कोंडापूर',
          assignedVillages: ['कोंडापूर', 'येवलेवाडी'],
        };
        showToast('लॉगिन यशस्वी');
        onSuccess(demoUser);
        return;
      }
      showToast('ईमेल सापडले नाही. कृपया नवीन नोंदणी करा.');
      return;
    }

    if (user.password && password && user.password !== password) {
      showToast('पासवर्ड चुकीचा आहे');
      return;
    }

    showToast(`स्वागत आहे, ${user.name}`);
    onSuccess(user);
  };

  const handleQuickLoginAs = (user: UserProfile) => {
    showToast(`लॉगिन यशस्वी: ${user.name}`);
    onSuccess(user);
  };

  // Handle Register submission
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const name = regName.trim();
    const designation = regDesignation.trim();
    const employeeId = regEmployeeId.trim();
    const email = regEmail.trim();
    const password = regPassword;

    if (!name || !designation || !employeeId || !email || !password) {
      showToast('कृपया सर्व आवश्यक वैयक्तिक माहिती भरा');
      return;
    }

    if (!effectivePhc) {
      showToast('कृपया प्राथमिक आरोग्य केंद्र (PHC) निवडा किंवा टाका');
      return;
    }

    if (!effectiveSubCenter) {
      showToast('कृपया उपकेंद्र (Sub Centre) निवडा किंवा टाका');
      return;
    }

    if (selectedVillages.length === 0 && !effectivePrimaryVillage) {
      showToast('कृपया किमान एक गाव निवडा किंवा जोडा');
      return;
    }

    if (password.length < 4) {
      showToast('पासवर्ड कमीत कमी 4 अक्षरांचा असावा');
      return;
    }

    const users = getAllUsers();
    if (users[email]) {
      showToast('हा ईमेल आधीच नोंदणीकृत आहे. कृपया लॉगिन करा.');
      return;
    }

    const allAssigned = Array.from(
      new Set([effectivePrimaryVillage, ...selectedVillages].filter(Boolean))
    );

    const newUser: UserProfile = {
      email,
      password,
      name,
      designation,
      employeeId,
      phone: regPhone.trim() || undefined,
      district: effectiveDistrict || 'पुणे',
      taluka: effectiveTaluka || 'हवेली',
      phc: effectivePhc,
      subCenter: effectiveSubCenter,
      village: effectivePrimaryVillage || allAssigned[0] || 'कोंडापूर',
      assignedVillages: allAssigned,
      createdAt: new Date().toISOString(),
    };

    users[email] = newUser;
    saveUsers(users);

    setRegisteredUsers(users);
    showToast('नवीन कर्मचारी नोंदणी यशस्वी झाली!');
    onSuccess(newUser);
  };

  // Handle Edit employee details submission
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const name = regName.trim();
    const designation = regDesignation.trim();
    const employeeId = regEmployeeId.trim();

    if (!name || !designation || !employeeId) {
      showToast('कृपया नाव, पद आणि कर्मचारी आयडी भरा');
      return;
    }

    if (!effectivePhc) {
      showToast('कृपया प्राथमिक आरोग्य केंद्र (PHC) निवडा किंवा टाका');
      return;
    }

    if (!effectiveSubCenter) {
      showToast('कृपया उपकेंद्र निवडा किंवा टाका');
      return;
    }

    const allAssigned = Array.from(
      new Set([effectivePrimaryVillage, ...selectedVillages].filter(Boolean))
    );

    const updatedUser: UserProfile = {
      ...editingUser,
      name,
      designation,
      employeeId,
      phone: regPhone.trim() || undefined,
      password: regPassword.trim() ? regPassword.trim() : editingUser.password,
      district: effectiveDistrict || 'पुणे',
      taluka: effectiveTaluka || 'हवेली',
      phc: effectivePhc,
      subCenter: effectiveSubCenter,
      village: effectivePrimaryVillage || allAssigned[0] || 'कोंडापूर',
      assignedVillages: allAssigned,
    };

    const nextUsers = updateUserProfile(updatedUser);
    setRegisteredUsers(nextUsers);

    if (currentUser?.email === updatedUser.email) {
      onUserUpdated?.(updatedUser);
    }

    showToast(`'${name}' यांची माहिती अद्यतनित झाली!`);
    setEditingUser(null);
    setMode('login');
  };

  // Handle confirmed deletion of an employee
  const handleDeleteUserConfirmed = (u: UserProfile) => {
    const users = getAllUsers();
    const totalCount = Object.keys(users).length;
    if (totalCount <= 1) {
      showToast('किमान एक कर्मचारी खाते असणे आवश्यक आहे. हे खाते हटवता येणार नाही.');
      setConfirmDeleteUser(null);
      return;
    }

    const nextUsers = deleteUserProfile(u.email);
    setRegisteredUsers(nextUsers);
    setConfirmDeleteUser(null);

    if (editingUser?.email === u.email) {
      setEditingUser(null);
      setMode('login');
    }

    onUserDeleted?.(u.email);
    showToast(`'${u.name}' यांचे कर्मचारी खाते हटवले.`);
  };

  const userEntries: UserProfile[] = Object.values(registeredUsers);

  return (
    <div
      id="authModal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#0A0A0A]/85 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-none shadow-2xl max-w-[530px] w-full max-h-[94vh] overflow-y-auto border border-[#E0DED6] my-auto">
        {/* TOP GOVERNMENT HEADER */}
        <div className="bg-[#0A0A0A] text-white p-4 rounded-t-xl text-center border-b border-[#0A0A0A] relative">
          {onClose && currentUser && (
            <button
              type="button"
              onClick={onClose}
              className="absolute top-3 right-3 text-white/70 hover:text-white text-lg p-1 rounded-none cursor-pointer"
              title="बंद करा"
            >
              ✕
            </button>
          )}
          <div className="h-1 w-24 bg-gradient-to-r from-[#0A0A0A] via-white to-[#1E7B34] mx-auto mb-2" />
          <div className="text-[11px] font-bold text-[#0A0A0A] uppercase tracking-wider">
            महाराष्ट्र शासन • सार्वजनिक आरोग्य विभाग
          </div>
          <div className="text-[17px] font-extrabold text-white mt-0.5">
            कंटेनर सर्वेक्षण व डास अळी नियंत्रण
          </div>
          <div className="text-[11.5px] text-[#9A9A9A] mt-0.5">
            {mode === 'edit'
              ? 'कर्मचारी माहिती व कार्यक्षेत्र संपादन (Edit Employee Details)'
              : mode === 'register'
              ? 'नवीन कर्मचारी नोंदणी (New Employee Registration)'
              : 'कर्मचारी निवड, संपादन व लॉगिन प्रणाली'}
          </div>

          {/* TAB / ACTION SWITCHER */}
          <div className="flex bg-[#0A0A0A] p-1 rounded-none mt-3 text-[12.5px] font-bold">
            <button
              type="button"
              onClick={() => {
                setEditingUser(null);
                setMode('login');
              }}
              className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-[#0A2540] shadow-xs'
                  : 'text-[#D9E2EC] hover:text-white'
              }`}
            >
              कर्मचारी सूची (Staff List)
            </button>
            <button
              type="button"
              onClick={() => {
                resetRegisterFields();
                setMode('register');
              }}
              className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-[#107C41] text-white shadow-xs'
                  : 'text-[#D9E2EC] hover:text-white'
              }`}
            >
              + नवीन नोंदणी (New)
            </button>
            {mode === 'edit' && (
              <button
                type="button"
                className="flex-1 py-1.5 rounded-none bg-[#8A5A00] text-white font-extrabold"
              >
                ✏️ संपादन (Edit)
              </button>
            )}
          </div>
        </div>

        <div className="p-4 sm:p-5">
          {/* ================= INLINE DELETE CONFIRMATION DIALOG ================= */}
          {confirmDeleteUser && (
            <div
              id="confirmDeleteBox"
              className="bg-[#FBEDEB] border-2 border-[#FBEDEB] rounded-none p-4 mb-4 animate-in fade-in"
            >
              <div className="flex items-center gap-2 text-[#B3261E] font-extrabold text-[14.5px] mb-2">
                <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                <span>कर्मचारी खाते हटवायचे आहे का? (Confirm Deletion)</span>
              </div>
              <p className="text-[12.5px] text-[#B3261E] mb-2 leading-relaxed">
                खात्री करा: <b>{confirmDeleteUser.name}</b> ({confirmDeleteUser.designation}, आयडी:{' '}
                {confirmDeleteUser.employeeId}) यांचे खाते कायमस्वरूपी हटवायचे आहे का?
              </p>
              <div className="text-[11px] text-[#B3261E] bg-white p-2 rounded-none border border-[#FBEDEB] mb-3">
                ⚠️ <b>टीप:</b> हे खाते हटवल्यास या कर्मचाऱ्याचे लॉगिन काढले जाईल. त्यांनी नोंदवलेला आधीचा सर्वेक्षण डेटा सुरक्षित राहील.
              </div>
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmDeleteUser(null)}
                  className="px-3 py-1.5 bg-white hover:bg-[#F4F3EF] text-[#6E6E6E] text-[12px] font-bold rounded-none border border-[#9A9A9A] cursor-pointer"
                >
                  रद्द करा (Cancel)
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteUserConfirmed(confirmDeleteUser)}
                  className="px-4 py-1.5 bg-[#B3261E] hover:bg-[#B3261E] text-white text-[12.5px] font-extrabold rounded-none cursor-pointer "
                >
                  होय, खाते हटवा (Delete)
                </button>
              </div>
            </div>
          )}

          {/* ================= 1. LOGIN & STAFF DIRECTORY VIEW ================= */}
          {mode === 'login' && (
            <div id="loginSection">
              {/* STAFF DIRECTORY WITH EDIT & DELETE CONTROLS */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[12.5px] font-extrabold text-[#0A0A0A] uppercase tracking-wide flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-none bg-[#1E7B34]"></span>
                    <span>नोंदणीकृत कर्मचारी खाती ({userEntries.length})</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      resetRegisterFields();
                      setMode('register');
                    }}
                    className="text-[11.5px] text-[#0A0A0A] font-bold hover:underline cursor-pointer"
                  >
                    + नवीन कर्मचारी जोडा
                  </button>
                </div>

                <div className="space-y-2.5 max-h-[290px] overflow-y-auto pr-1">
                  {userEntries.map((u) => {
                    const isCurrent = currentUser?.email === u.email;
                    return (
                      <div
                        key={u.email}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isCurrent
                            ? 'bg-[#F0F7FF] border-[#0F4C81] ring-1 ring-[#0F4C81]'
                            : 'bg-white border-[#D9E2EC] hover:border-[#BCCCDC]'
                        }`}
                      >
                        {/* TOP ROW: NAME & STATUS */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-extrabold text-[14.5px] text-[#0A0A0A]">
                                {u.name}
                              </span>
                              <span className="text-[11px] font-bold px-1.5 py-0.2 bg-[#F4F3EF] text-[#6E6E6E] rounded-none">
                                {u.designation}
                              </span>
                              {u.employeeId && (
                                <span className="text-[10.5px] text-[#6E6E6E] font-mono">
                                  [{u.employeeId}]
                                </span>
                              )}
                              {isCurrent && (
                                <span className="text-[10px] font-extrabold bg-[#1E7B34] text-white px-1.5 py-0.2 rounded-none">
                                  सध्या सुरू
                                </span>
                              )}
                            </div>

                            {/* LOCATION SUB-DETAILS */}
                            <div className="text-[11.5px] text-[#6E6E6E] mt-1 flex items-center flex-wrap gap-1">
                              <span className="font-medium text-[#0A0A0A]">{u.phc || 'प्रा.आ. केंद्र'}</span>
                              <span>•</span>
                              <span>{u.subCenter || 'उपकेंद्र'}</span>
                              {u.village && (
                                <>
                                  <span>•</span>
                                  <span>
                                    मुख्यालय:{' '}
                                    <b className="text-[#0A0A0A]">{u.village}</b>
                                  </span>
                                </>
                              )}
                              {u.phone && (
                                <span className="text-[#6E6E6E] ml-1">
                                  (📞 {u.phone})
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* BOTTOM ROW: ACTIONS (LOGIN, EDIT, DELETE) */}
                        <div className="mt-2.5 pt-2 border-t border-[#E0DED6] flex items-center justify-between gap-2">
                          <span className="text-[11px] text-[#9A9A9A] truncate">
                            {u.email}
                          </span>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* EDIT BUTTON */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                startEditUser(u);
                              }}
                              className="px-2.5 py-1 bg-white hover:bg-[#F4F3EF] text-[#0A0A0A] hover:text-[#0A0A0A] border border-[#9A9A9A] rounded-none text-[11.5px] font-bold cursor-pointer transition-colors flex items-center gap-1 "
                              title="कर्मचारी माहिती व कार्यक्षेत्र संपादन करा"
                            >
                              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                              <span>संपादन</span>
                            </button>

                            {/* DELETE BUTTON */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setConfirmDeleteUser(u);
                              }}
                              className="px-2 py-1 bg-white hover:bg-[#FBEDEB] text-[#B3261E] hover:text-[#B3261E] border border-[#FBEDEB] rounded-none text-[11.5px] font-bold cursor-pointer transition-colors flex items-center gap-1 "
                              title="कर्मचारी खाते हटवा"
                            >
                              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                              <span>हटवा</span>
                            </button>

                            {/* LOGIN BUTTON */}
                            {!isCurrent ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuickLoginAs(u);
                                }}
                                className="px-3 py-1 bg-[#0A0A0A] hover:bg-[#0A0A0A] text-white rounded-none text-[11.5px] font-extrabold cursor-pointer transition-colors "
                              >
                                लॉगिन
                              </button>
                            ) : (
                              <span className="text-[11px] font-bold text-[#1E7B34] px-2 py-0.5">
                                ✓ सक्रिय
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* DIVIDER */}
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-[#E0DED6]"></div>
                <span className="flex-shrink mx-3 text-[#9A9A9A] text-[11px] font-bold uppercase">
                  किंवा ईमेल द्वारे लॉगिन करा
                </span>
                <div className="flex-grow border-t border-[#E0DED6]"></div>
              </div>

              {/* LOGIN FORM */}
              <form id="loginForm" onSubmit={handleLogin} className="space-y-3 mt-1">
                <div>
                  <label
                    htmlFor="login-email"
                    className="block text-[12.5px] font-bold text-[#6E6E6E] mb-1"
                  >
                    नोंदणीकृत ईमेल आयडी (Email ID)
                  </label>
                  <input
                    type="email"
                    id="login-email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="उदा. patya.mohite@gmail.com"
                    className="w-full border border-[#E0DED6] rounded-none p-2.5 text-[14px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A] focus:ring-1 focus:ring-[#0A0A0A]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="login-password"
                    className="block text-[12.5px] font-bold text-[#6E6E6E] mb-1"
                  >
                    पासवर्ड (Password)
                  </label>
                  <input
                    type="password"
                    id="login-password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full border border-[#E0DED6] rounded-none p-2.5 text-[14px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A] focus:ring-1 focus:ring-[#0A0A0A]"
                  />
                </div>

                <button
                  id="loginBtn"
                  type="submit"
                  className="w-full p-3 bg-[#0A0A0A] hover:bg-[#0A0A0A] active:bg-[#0A0A0A] text-white rounded-none font-extrabold text-[14.5px] cursor-pointer transition-colors flex items-center justify-center gap-2"
                >
                  <span>प्रवेश करा (Sign In)</span>
                </button>
              </form>
            </div>
          )}

          {/* ================= 2. EDIT OR REGISTER EMPLOYEE FORM ================= */}
          {(mode === 'edit' || mode === 'register') && (
            <form
              id={mode === 'edit' ? 'editEmployeeForm' : 'registerForm'}
              onSubmit={mode === 'edit' ? handleSaveEdit : handleRegister}
            >
              {/* EDITING CONTEXT BANNER */}
              {mode === 'edit' && editingUser && (
                <div className="bg-[#FBF3DF] border border-[#FBF3DF] rounded-none p-2.5 mb-3 flex items-center justify-between text-[12px] text-[#8A5A00]">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px]">✏️</span>
                    <span>
                      संपादन: <b>{editingUser.name}</b> ({editingUser.email})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingUser(null);
                      setMode('login');
                    }}
                    className="text-[#8A5A00] font-bold underline hover:text-[#8A5A00] cursor-pointer"
                  >
                    रद्द करा
                  </button>
                </div>
              )}

              <div className="space-y-3.5">
                {/* 1. वैयक्तिक माहिती */}
                <div className="bg-[#F4F3EF] p-3 rounded-none border border-[#E0DED6]">
                  <div className="text-[11.5px] font-extrabold text-[#0A0A0A] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DED6] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-none bg-[#0A0A0A]"></span>
                    <span>१. कर्मचारी वैयक्तिक माहिती</span>
                  </div>

                  <div className="space-y-2.5">
                    <div>
                      <label
                        htmlFor="reg-name"
                        className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                      >
                        पूर्ण नाव *
                      </label>
                      <input
                        type="text"
                        id="reg-name"
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="उदा. श्री. पांडुरंग मोहिते / श्रीमती अनिता सुतार"
                        className="w-full border border-[#E0DED6] rounded-none p-2 text-[13.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A]"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label
                          htmlFor="reg-designation"
                          className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                        >
                          पद / पदनाम *
                        </label>
                        <select
                          id="reg-designation"
                          value={regDesignation}
                          onChange={(e) => setRegDesignation(e.target.value)}
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[12.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A] cursor-pointer"
                        >
                          <option value="आरोग्य सेवक / MPW">आरोग्य सेवक / MPW</option>
                          <option value="आरोग्य सेविका / ANM">आरोग्य सेविका / ANM</option>
                          <option value="आरोग्य सहाय्यक / HA">आरोग्य सहाय्यक / HA</option>
                          <option value="कीटक संकलक">कीटक संकलक (Insect Collector)</option>
                          <option value="वैद्यकीय अधिकारी">वैद्यकीय अधिकारी (MO)</option>
                          <option value="आशा स्वयंसेविका / ASHA">आशा स्वयंसेविका / ASHA</option>
                        </select>
                      </div>

                      <div>
                        <label
                          htmlFor="reg-employee-id"
                          className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                        >
                          कर्मचारी आयडी *
                        </label>
                        <input
                          type="text"
                          id="reg-employee-id"
                          value={regEmployeeId}
                          onChange={(e) => setRegEmployeeId(e.target.value)}
                          placeholder="उदा. MH-PHD-408"
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A]"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="reg-phone"
                        className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                      >
                        मोबाईल / संपर्क क्रमांक (वैकल्पिक)
                      </label>
                      <input
                        type="tel"
                        id="reg-phone"
                        value={regPhone}
                        onChange={(e) => setRegPhone(e.target.value)}
                        placeholder="उदा. 9876543210"
                        className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A]"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. प्रशासकीय कार्यक्षेत्र (Jurisdiction Details) */}
                <div className="bg-[#EAF5EC] p-3 rounded-none border border-[#EAF5EC]">
                  <div className="text-[11.5px] font-extrabold text-[#1E7B34] uppercase tracking-wider mb-2 pb-1 border-b border-[#EAF5EC] flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-none bg-[#1E7B34]"></span>
                      <span>२. प्रशासकीय कार्यक्षेत्र पर्याय (Jurisdiction)</span>
                    </span>
                    <span className="text-[10px] font-normal text-[#1E7B34] bg-white px-1.5 py-0.5 rounded-none border border-[#EAF5EC]">
                      महाराष्ट्र आरोग्य विभाग
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {/* जिल्हा व तालुका */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label
                          htmlFor="reg-district"
                          className="block text-[12px] font-bold text-[#1E7B34] mb-0.5"
                        >
                          जिल्हा (District) *
                        </label>
                        <select
                          id="reg-district"
                          value={regDistrict}
                          onChange={(e) => handleDistrictChange(e.target.value)}
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[12.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34] cursor-pointer"
                        >
                          {districtList.map((d) => (
                            <option key={d} value={d}>
                              {d}
                            </option>
                          ))}
                          <option value="__OTHER__">+ इतर जिल्हा (नवीन नाव टाका)</option>
                        </select>
                        {regDistrict === '__OTHER__' && (
                          <input
                            type="text"
                            value={customDistrict}
                            onChange={(e) => setCustomDistrict(e.target.value)}
                            placeholder="जिल्ह्याचे नाव टाका"
                            className="w-full mt-1 border border-[#1E7B34] rounded-none p-1.5 text-[12px] bg-white text-[#0A0A0A]"
                            required
                          />
                        )}
                      </div>

                      <div>
                        <label
                          htmlFor="reg-taluka"
                          className="block text-[12px] font-bold text-[#1E7B34] mb-0.5"
                        >
                          तालुका (Taluka) *
                        </label>
                        {regDistrict !== '__OTHER__' && talukaList.length > 0 ? (
                          <select
                            id="reg-taluka"
                            value={regTaluka}
                            onChange={(e) =>
                              handleTalukaChange(regDistrict, e.target.value)
                            }
                            className="w-full border border-[#E0DED6] rounded-none p-2 text-[12.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34] cursor-pointer"
                          >
                            {talukaList.map((t) => (
                              <option key={t} value={t}>
                                {t}
                              </option>
                            ))}
                            <option value="__OTHER__">+ इतर तालुका (नवीन)</option>
                          </select>
                        ) : (
                          <input
                            type="text"
                            value={customTaluka}
                            onChange={(e) => setCustomTaluka(e.target.value)}
                            placeholder="उदा. हवेली / शिरूर"
                            className="w-full border border-[#E0DED6] rounded-none p-2 text-[12.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34]"
                            required
                          />
                        )}
                        {regDistrict !== '__OTHER__' && regTaluka === '__OTHER__' && (
                          <input
                            type="text"
                            value={customTaluka}
                            onChange={(e) => setCustomTaluka(e.target.value)}
                            placeholder="तालुक्याचे नाव टाका"
                            className="w-full mt-1 border border-[#1E7B34] rounded-none p-1.5 text-[12px] bg-white text-[#0A0A0A]"
                            required
                          />
                        )}
                      </div>
                    </div>

                    {/* प्राथमिक आरोग्य केंद्र (PHC Options) */}
                    <div>
                      <label
                        htmlFor="reg-phc"
                        className="block text-[12px] font-bold text-[#1E7B34] mb-0.5 flex items-center justify-between"
                      >
                        <span>प्राथमिक आरोग्य केंद्र (PHC Name Option) *</span>
                        <span className="text-[10px] font-normal text-[#6E6E6E]">
                          पर्याय निवडा किंवा स्वतः टाका
                        </span>
                      </label>
                      {regDistrict !== '__OTHER__' &&
                      regTaluka !== '__OTHER__' &&
                      phcList.length > 0 ? (
                        <select
                          id="reg-phc"
                          value={regPhc}
                          onChange={(e) =>
                            handlePhcChange(regDistrict, regTaluka, e.target.value)
                          }
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34] cursor-pointer"
                        >
                          {phcList.map((p) => (
                            <option key={p} value={p}>
                              {p}
                            </option>
                          ))}
                          <option value="__OTHER__">+ इतर नवीन प्रा.आ.केंद्र टाका...</option>
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={customPhc}
                          onChange={(e) => setCustomPhc(e.target.value)}
                          placeholder="उदा. प्रा.आ. केंद्र कोंढवा"
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34]"
                          required
                        />
                      )}

                      {regDistrict !== '__OTHER__' &&
                        regTaluka !== '__OTHER__' &&
                        regPhc === '__OTHER__' && (
                          <input
                            type="text"
                            value={customPhc}
                            onChange={(e) => setCustomPhc(e.target.value)}
                            placeholder="नवीन प्राथमिक आरोग्य केंद्राचे नाव टाका (उदा. प्रा.आ. केंद्र वाघोली)"
                            className="w-full mt-1.5 border-2 border-[#1E7B34] rounded-none p-2 text-[13px] bg-white text-[#0A0A0A]"
                            required
                          />
                        )}
                    </div>

                    {/* आरोग्य उपकेंद्र (Sub-Center Options) */}
                    <div>
                      <label
                        htmlFor="reg-subcenter"
                        className="block text-[12px] font-bold text-[#1E7B34] mb-0.5 flex items-center justify-between"
                      >
                        <span>आरोग्य उपकेंद्र (Sub Centre Name Option) *</span>
                        <span className="text-[10px] font-normal text-[#6E6E6E]">
                          PHC अंतर्गत उपकेंद्र
                        </span>
                      </label>
                      {regDistrict !== '__OTHER__' &&
                      regTaluka !== '__OTHER__' &&
                      regPhc !== '__OTHER__' &&
                      subCenterList.length > 0 ? (
                        <select
                          id="reg-subcenter"
                          value={regSubCenter}
                          onChange={(e) =>
                            handleSubCenterChange(
                              regDistrict,
                              regTaluka,
                              regPhc,
                              e.target.value
                            )
                          }
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34] cursor-pointer"
                        >
                          {subCenterList.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                          <option value="__OTHER__">+ इतर नवीन उपकेंद्र नाव टाका...</option>
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={customSubCenter}
                          onChange={(e) => setCustomSubCenter(e.target.value)}
                          placeholder="उदा. उपकेंद्र कोंडापूर"
                          className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34]"
                          required
                        />
                      )}

                      {regDistrict !== '__OTHER__' &&
                        regTaluka !== '__OTHER__' &&
                        regPhc !== '__OTHER__' &&
                        regSubCenter === '__OTHER__' && (
                          <input
                            type="text"
                            value={customSubCenter}
                            onChange={(e) => setCustomSubCenter(e.target.value)}
                            placeholder="नवीन उपकेंद्राचे नाव टाका (उदा. उपकेंद्र कोंडापूर)"
                            className="w-full mt-1.5 border-2 border-[#1E7B34] rounded-none p-2 text-[13px] bg-white text-[#0A0A0A]"
                            required
                          />
                        )}
                    </div>

                    {/* गाव / कार्यक्षेत्रातील गावे (Village Name Options) */}
                    <div>
                      <label className="block text-[12px] font-bold text-[#1E7B34] mb-1 flex items-center justify-between">
                        <span>कार्यक्षेत्रातील गाव पर्याय (Assigned Village Options) *</span>
                        <span className="text-[10px] font-semibold text-[#1E7B34]">
                          {selectedVillages.length} गावे निवडली
                        </span>
                      </label>

                      {/* Clickable Preset Village Pills */}
                      {defaultVillagesForSubCenter.length > 0 && (
                        <div className="mb-2">
                          <div className="text-[11px] text-[#6E6E6E] mb-1">
                            या उपकेंद्रातील गावे (टॅप करून जोडा/काढा):
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {defaultVillagesForSubCenter.map((v) => {
                              const isSelected = selectedVillages.includes(v);
                              const isPrimary = regPrimaryVillage === v;
                              return (
                                <button
                                  type="button"
                                  key={v}
                                  onClick={() => toggleVillage(v)}
                                  className={`px-2.5 py-1 rounded-full text-[11.5px] font-bold transition-all cursor-pointer flex items-center gap-1 border ${
                                    isSelected
                                      ? 'bg-[#107C41] text-white border-[#107C41] shadow-2xs'
                                      : 'bg-white text-[#486581] border-[#D9E2EC] hover:bg-[#F4F6F9]'
                                  }`}
                                >
                                  <span>{v}</span>
                                  {isPrimary && (
                                    <span className="text-[9.5px] bg-[#0A0A0A] text-black px-1 rounded-none">
                                      मुख्य
                                    </span>
                                  )}
                                  <span>{isSelected ? '✓' : '+'}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Custom Village Adder */}
                      <div className="flex gap-1.5 mt-1.5">
                        <input
                          type="text"
                          value={newVillageInput}
                          onChange={(e) => setNewVillageInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddCustomVillage();
                            }
                          }}
                          placeholder="+ आणखी गाव किंवा वस्तीचे नाव जोडा"
                          className="flex-1 border border-[#E0DED6] rounded-none p-1.5 text-[12.5px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34]"
                        />
                        <button
                          type="button"
                          onClick={handleAddCustomVillage}
                          className="px-3 py-1.5 bg-[#1E7B34] hover:bg-[#1E7B34] text-white rounded-none text-[12px] font-bold cursor-pointer transition-colors"
                        >
                          जोडा
                        </button>
                      </div>

                      {/* Primary Village Selector */}
                      {selectedVillages.length > 0 && (
                        <div className="mt-2 pt-2 border-t border-[#EAF5EC] flex items-center justify-between gap-2">
                          <label
                            htmlFor="reg-primary-village"
                            className="text-[11.5px] font-bold text-[#1E7B34] shrink-0"
                          >
                            मुख्य कार्यक्षेत्र गाव (Headquarters):
                          </label>
                          <select
                            id="reg-primary-village"
                            value={regPrimaryVillage}
                            onChange={(e) => setRegPrimaryVillage(e.target.value)}
                            className="border border-[#E0DED6] rounded-none p-1 text-[12px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#1E7B34] cursor-pointer max-w-[200px]"
                          >
                            {selectedVillages.map((v) => (
                              <option key={v} value={v}>
                                {v}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {/* Display Selected Villages Badges */}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {selectedVillages.map((v) => (
                          <span
                            key={v}
                            className="inline-flex items-center gap-1 text-[11px] bg-white border border-[#1E7B34]/40 text-[#1E7B34] px-2 py-0.5 rounded-none font-medium"
                          >
                            <span>{v}</span>
                            {regPrimaryVillage === v && (
                              <span className="text-[9px] font-bold text-[#0A0A0A]">★ मुख्य</span>
                            )}
                            <button
                              type="button"
                              onClick={() => toggleVillage(v)}
                              className="text-[#B3261E] hover:text-red-700 ml-0.5 cursor-pointer font-bold"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Summary badge */}
                    <div className="p-2 bg-white rounded-none border border-[#EAF5EC] text-[11.5px] text-[#1E7B34]">
                      <span className="font-bold">कार्यक्षेत्र सारांश: </span>
                      <span>
                        {effectivePhc || 'PHC'} ➔ {effectiveSubCenter || 'उपकेंद्र'} ➔ मुख्य गाव:{' '}
                        <b>{effectivePrimaryVillage || 'कोंडापूर'}</b>
                        {selectedVillages.length > 1 &&
                          ` (+ इतर ${selectedVillages.length - 1} गावे)`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. सुरक्षा व क्रेडेंशियल तपशील */}
                <div className="bg-[#F4F3EF] p-3 rounded-none border border-[#E0DED6]">
                  <div className="text-[11.5px] font-extrabold text-[#0A0A0A] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DED6] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-none bg-[#0A0A0A]"></span>
                    <span>३. सुरक्षा व लॉगिन क्रेडेंशियल</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label
                        htmlFor="reg-email"
                        className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                      >
                        ईमेल आयडी {mode === 'edit' ? '(बदलता येत नाही)' : '*'}
                      </label>
                      <input
                        type="email"
                        id="reg-email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        disabled={mode === 'edit'}
                        placeholder="नाव@gmail.com"
                        className={`w-full border rounded-lg p-2 text-[13px] ${
                          mode === 'edit'
                            ? 'bg-[#E2E8F0] text-[#64748B] border-[#CBD5E1] cursor-not-allowed'
                            : 'border-[#D9E2EC] text-[#102A43] bg-white focus:outline-none focus:border-[#0F4C81]'
                        }`}
                        required
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="reg-password"
                        className="block text-[12px] font-bold text-[#6E6E6E] mb-0.5"
                      >
                        {mode === 'edit'
                          ? 'नवीन पासवर्ड (बदलायचा असल्यास)'
                          : 'पासवर्ड *'}
                      </label>
                      <input
                        type="password"
                        id="reg-password"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder={
                          mode === 'edit'
                            ? 'जुना पासवर्ड तसाच ठेवण्यासाठी रिकामे ठेवा'
                            : 'कमीत कमी ४ अक्षरे'
                        }
                        className="w-full border border-[#E0DED6] rounded-none p-2 text-[13px] text-[#0A0A0A] bg-white focus:outline-none focus:border-[#0A0A0A]"
                        required={mode === 'register'}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* ACTION BUTTONS (SAVE / CANCEL / DELETE) */}
              <div className="mt-4 space-y-2">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingUser(null);
                      setMode('login');
                    }}
                    className="flex-1 py-2.5 px-3 bg-[#F4F3EF] hover:bg-[#E0DED6] text-[#6E6E6E] rounded-none font-bold text-[13.5px] cursor-pointer transition-colors"
                  >
                    रद्द करा (Cancel)
                  </button>

                  <button
                    id={mode === 'edit' ? 'saveEditBtn' : 'registerBtn'}
                    type="submit"
                    className="flex-2 py-2.5 px-4 bg-[#1E7B34] hover:bg-[#1E7B34] active:bg-[#1E7B34] text-white rounded-none font-extrabold text-[14px] cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>
                      {mode === 'edit'
                        ? 'बदल जतन करा (Save Changes)'
                        : 'नोंदणी पूर्ण करा व लॉगिन व्हा'}
                    </span>
                  </button>
                </div>

                {/* DELETE ACCOUNT FROM EDIT SCREEN */}
                {mode === 'edit' && editingUser && (
                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteUser(editingUser)}
                      className="text-[#B3261E] hover:text-[#B3261E] text-[12px] font-bold underline cursor-pointer inline-flex items-center gap-1"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                      <span>हे कर्मचारी खाते कायमचे हटवा (Delete This Account)</span>
                    </button>
                  </div>
                )}
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
