import React, { useState, useMemo } from 'react';
import { SurveyRecord } from '../types';
import { formatDateLabel, formatIndianDate, todayStr } from '../utils/storage';

interface RecordsTabProps {
  records: SurveyRecord[];
  villages: string[];
  onEdit: (record: SurveyRecord) => void;
  onDelete: (id: string) => void;
  onOpenPdfReport?: (filter?: { from: string; to: string; village: string }) => void;
}

export const RecordsTab: React.FC<RecordsTabProps> = ({
  records,
  villages,
  onEdit,
  onDelete,
  onOpenPdfReport,
}) => {
  const [selectedVillage, setSelectedVillage] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');

  const filteredRecords = useMemo(() => {
    let items = records.slice();
    if (selectedVillage) {
      items = items.filter((r) => r.village === selectedVillage);
    }
    if (fromDate) {
      items = items.filter((r) => r.date >= fromDate);
    }
    if (toDate) {
      items = items.filter((r) => r.date <= toDate);
    }
    items.sort((a, b) => {
      const keyA = a.date + a.id;
      const keyB = b.date + b.id;
      return sortDir === 'desc' ? keyB.localeCompare(keyA) : keyA.localeCompare(keyB);
    });
    return items;
  }, [records, selectedVillage, fromDate, toDate, sortDir]);

  // Group by date
  const grouped = useMemo(() => {
    const groups: { date: string; dateLabel: string; items: SurveyRecord[] }[] = [];
    let currentDate = '';
    let currentGroup: SurveyRecord[] = [];

    filteredRecords.forEach((r) => {
      if (r.date !== currentDate) {
        if (currentDate && currentGroup.length > 0) {
          groups.push({
            date: currentDate,
            dateLabel: formatDateLabel(currentDate),
            items: currentGroup,
          });
        }
        currentDate = r.date;
        currentGroup = [r];
      } else {
        currentGroup.push(r);
      }
    });

    if (currentDate && currentGroup.length > 0) {
      groups.push({
        date: currentDate,
        dateLabel: formatDateLabel(currentDate),
        items: currentGroup,
      });
    }

    return groups;
  }, [filteredRecords]);

  const handleDeleteClick = (id: string) => {
    if (window.confirm('ही घराची शासकीय नोंद हटवायची का? ही क्रिया पूर्ववत करता येणार नाही.')) {
      onDelete(id);
    }
  };

  const handlePdfClick = () => {
    if (onOpenPdfReport) {
      onOpenPdfReport({
        from: fromDate,
        to: toDate,
        village: selectedVillage,
      });
    }
  };

  const isFiltered = Boolean(fromDate || toDate || selectedVillage);

  return (
    <section id="page-records" className="w-full">
      {/* FILTER PANEL */}
      <div className="rule-card p-4 mb-4">
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="mono-label">नोंदी शोधा / फिल्टर करा</span>
          {isFiltered && (
            <button
              type="button"
              onClick={() => {
                setFromDate('');
                setToDate('');
                setSelectedVillage('');
              }}
              className="mono-label-sm underline underline-offset-2 cursor-pointer"
            >
              फिल्टर साफ करा
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <div>
            <label className="field-label !text-[11px]">दिनांक पासून:</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="field !p-1.5 !text-[12.5px]"
            />
          </div>
          <div>
            <label className="field-label !text-[11px]">दिनांक पर्यंत:</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="field !p-1.5 !text-[12.5px]"
            />
          </div>
          <div>
            <label className="field-label !text-[11px]">गाव:</label>
            <select
              id="filterVillage"
              value={selectedVillage}
              onChange={(e) => setSelectedVillage(e.target.value)}
              className="field !p-1.5 !text-[12.5px] cursor-pointer"
            >
              <option value="">सर्व गावे</option>
              {villages.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label !text-[11px]">क्रमवारी:</label>
            <select
              id="filterSort"
              value={sortDir}
              onChange={(e) => setSortDir(e.target.value as 'desc' | 'asc')}
              className="field !p-1.5 !text-[12.5px] cursor-pointer"
            >
              <option value="desc">नवीन आधी</option>
              <option value="asc">जुने आधी</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2.5 border-t border-[#0A0A0A] text-[12px] text-[#6E6E6E]">
          <span>
            नोंदी: <b className="text-[#0A0A0A]">{filteredRecords.length}</b> पैकी {records.length}
            {(fromDate || toDate) && (
              <span className="ml-1">
                ({fromDate ? formatIndianDate(fromDate) : 'सुरुवात'} ते {toDate ? formatIndianDate(toDate) : 'आज'})
              </span>
            )}
          </span>
          {onOpenPdfReport && (
            <button
              type="button"
              onClick={handlePdfClick}
              className="btn-ghost !py-1.5 !px-2.5"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              या नोंदींचा PDF
            </button>
          )}
        </div>
      </div>

      {/* RECORDS LIST */}
      <div id="recordsList">
        {filteredRecords.length === 0 ? (
          <div className="text-center py-12 px-4 text-[#6E6E6E] bg-white border border-[#0A0A0A]/25">
            <div className="w-12 h-12 border border-[#0A0A0A] flex items-center justify-center mx-auto mb-3 text-xl text-[#0A0A0A]">
              📋
            </div>
            <p className="text-[14px] font-bold text-[#0A0A0A] m-0">
              अद्याप कोणतीही तपासणी नोंद उपलब्ध नाही.
            </p>
            <p className="text-[12.5px] text-[#6E6E6E] mt-1 m-0">
              नवीन नोंद करण्यासाठी खालील 'नवीन नोंद' पर्यायावर टॅप करा.
            </p>
          </div>
        ) : (
          grouped.map((group) => (
            <div key={group.date} className="mb-5">
              <div className="section-eyebrow !mb-3">
                <span className="num">▪</span>
                <span className="mono-label">{group.dateLabel}</span>
                <span className="rule"></span>
              </div>

              <div className="space-y-3">
                {group.items.map((r) => {
                  const isPos = r.housesPositive > 0;
                  return (
                    <div key={r.id} className="rule-card p-4">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <div className="font-extrabold text-[15px] text-[#0A0A0A] tracking-tight">
                            {r.head}
                          </div>
                          <div className="text-[12px] text-[#6E6E6E] mt-0.5">
                            गाव: <b className="text-[#0A0A0A]">{r.village}</b>
                            {r.members > 0 && ` • सदस्य: ${r.members}`}
                          </div>
                        </div>

                        <div
                          className={`mono-label-sm px-2.5 py-1 whitespace-nowrap border ${
                            isPos
                              ? 'bg-[#FBEDEB] text-[#B3261E] border-[#B3261E]'
                              : 'bg-[#EAF5EC] text-[#1E7B34] border-[#1E7B34]'
                          }`}
                        >
                          {isPos ? 'पॉझिटिव्ह' : 'निगेटिव्ह'}
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-px mt-3 bg-[#0A0A0A]/20 border border-[#0A0A0A]/20 text-center">
                        <div className="bg-white p-2">
                          <div className="mono-label-sm text-[#9A9A9A]">तपासलेली घरे</div>
                          <div className="font-black text-[15px] text-[#0A0A0A] mt-0.5">{r.housesInspected}</div>
                        </div>
                        <div className="bg-white p-2">
                          <div className="mono-label-sm text-[#9A9A9A]">कंटेनर</div>
                          <div className="font-black text-[15px] text-[#0A0A0A] mt-0.5">{r.containersInspected}</div>
                        </div>
                        <div className="bg-white p-2">
                          <div className="mono-label-sm text-[#B3261E]">पॉझिटिव्ह</div>
                          <div className="font-black text-[15px] text-[#B3261E] mt-0.5">{r.containersPositive}</div>
                        </div>
                        <div className="bg-white p-2">
                          <div className="mono-label-sm text-[#1E7B34]">अबेट उपचार</div>
                          <div className="font-black text-[15px] text-[#1E7B34] mt-0.5">
                            {r.abate ? 'होय' : 'नाही'}
                          </div>
                        </div>
                      </div>

                      {r.notes && (
                        <div className="text-[12px] text-[#6E6E6E] mt-2.5 pt-2.5 border-t border-[#0A0A0A]/15">
                          <span className="mono-label-sm text-[#0A0A0A]">निरीक्षण — </span>
                          {r.notes}
                        </div>
                      )}

                      <div className="flex gap-2 mt-3 pt-3 border-t border-[#0A0A0A]">
                        <button
                          type="button"
                          onClick={() => onEdit(r)}
                          className="btn-ghost flex-1 !py-2"
                        >
                          संपादित करा
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteClick(r.id)}
                          className="mono-label-sm px-4 py-2 border border-[#B3261E] text-[#B3261E] hover:bg-[#B3261E] hover:text-white cursor-pointer transition-colors"
                        >
                          हटवा
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
};
