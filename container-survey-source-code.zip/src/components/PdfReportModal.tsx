import React, { useState, useMemo, useEffect } from 'react';
import { SurveyRecord, SurveyTotals, UserProfile } from '../types';
import { exportReportToPdf, getRiskLevel } from '../utils/pdfExport';
import { formatDateLabel, formatIndianDate, todayStr, calculateTotals } from '../utils/storage';

interface PdfReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: SurveyRecord[];
  totals: SurveyTotals;
  currentUser: UserProfile | null;
  selectedVillage?: string;
  dateRangeText?: string;
  initialFromDate?: string;
  initialToDate?: string;
  showToast: (msg: string) => void;
}

export const PdfReportModal: React.FC<PdfReportModalProps> = ({
  isOpen,
  onClose,
  records,
  totals,
  currentUser,
  selectedVillage = '',
  dateRangeText,
  initialFromDate = '',
  initialToDate = '',
  showToast,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [pdfFrom, setPdfFrom] = useState(initialFromDate);
  const [pdfTo, setPdfTo] = useState(initialToDate);
  const [pdfVillage, setPdfVillage] = useState(selectedVillage);

  // Sync state if initial props change when modal opens
  useEffect(() => {
    if (isOpen) {
      setPdfFrom(initialFromDate);
      setPdfTo(initialToDate);
      setPdfVillage(selectedVillage || '');
    }
  }, [isOpen, initialFromDate, initialToDate, selectedVillage]);

  // Derive unique villages from records and worker profile
  const allVillages = useMemo(() => {
    const list = new Set<string>();
    if (currentUser?.assignedVillages) {
      currentUser.assignedVillages.forEach((v) => list.add(v));
    }
    if (currentUser?.village) {
      list.add(currentUser.village);
    }
    records.forEach((r) => {
      if (r.village) list.add(r.village);
    });
    return Array.from(list);
  }, [records, currentUser]);

  // Filter records dynamically by date range and village
  const activeRecords = useMemo(() => {
    return records.filter((r) => {
      if (pdfFrom && r.date < pdfFrom) return false;
      if (pdfTo && r.date > pdfTo) return false;
      if (pdfVillage && r.village !== pdfVillage) return false;
      return true;
    });
  }, [records, pdfFrom, pdfTo, pdfVillage]);

  // Recalculate totals and indices dynamically
  const activeTotals = useMemo(() => {
    return calculateTotals(activeRecords);
  }, [activeRecords]);

  const risk = getRiskLevel(activeTotals.hi, activeTotals.ci, activeTotals.bi);

  // Formatted date range label for official letterhead
  const dateRangeDisplay = useMemo(() => {
    if (pdfFrom && pdfTo) {
      if (pdfFrom === pdfTo) {
        return `${formatIndianDate(pdfFrom)} (दैनिक अहवाल)`;
      }
      return `${formatIndianDate(pdfFrom)} ते ${formatIndianDate(pdfTo)}`;
    }
    if (pdfFrom) return `${formatIndianDate(pdfFrom)} पासून पुढील अहवाल`;
    if (pdfTo) return `${formatIndianDate(pdfTo)} पर्यंतचा अहवाल`;
    return dateRangeText || 'सर्व उपलब्ध नोंदी (एकत्रित अहवाल)';
  }, [pdfFrom, pdfTo, dateRangeText]);

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setIsGenerating(true);
      showToast('PDF अहवाल तयार होत आहे, कृपया थांबा...');
      const safePrefix = `maharashtra-arogya-survey-${pdfFrom || 'all'}-to-${pdfTo || 'all'}`;
      await exportReportToPdf('official-report-printable', safePrefix);
      showToast('PDF यशस्वीरित्या डाऊनलोड झाली!');
    } catch (err) {
      console.error(err);
      showToast('PDF तयार करताना त्रुटी आली. कृपया प्रिंट पर्याय वापरा.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="pdfReportModal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-[#0A0A0A]/80 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-none shadow-2xl max-w-[890px] w-full max-h-[94vh] flex flex-col border border-[#E0DED6] my-auto">
        {/* MODAL ACTION BAR */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-3 bg-[#0A0A0A] text-white rounded-t-xl no-print">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-[#0A0A0A]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span className="font-bold text-[14px] sm:text-[15px] tracking-wide">
              शासकीय सर्वेक्षण अहवाल (PDF पूर्वदृश्य)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-none text-[12.5px] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
              </svg>
              प्रिंट
            </button>
            <button
              type="button"
              disabled={isGenerating}
              onClick={handleDownload}
              className="px-3.5 py-1.5 bg-[#1E7B34] hover:bg-[#1E7B34] text-white rounded-none text-[12.5px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 "
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              {isGenerating ? 'PDF बनत आहे...' : 'PDF डाऊनलोड करा'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white rounded-none transition-colors cursor-pointer text-xl ml-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* DATE RANGE FILTER TOOLBAR (IN-MODAL INTERACTIVE CONTROLS) */}
        <div className="bg-[#F4F3EF] border-b border-[#E0DED6] p-3 sm:px-5 no-print text-[#0A0A0A]">
          <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
            <div className="text-[12px] font-extrabold flex items-center gap-1.5 text-[#0A0A0A]">
              <span className="w-2 h-2 rounded-none bg-[#0A0A0A]"></span>
              अहवाल कालावधी व गाव फिल्टर:
            </div>
            {(pdfFrom || pdfTo || pdfVillage) && (
              <button
                type="button"
                onClick={() => {
                  setPdfFrom('');
                  setPdfTo('');
                  setPdfVillage('');
                }}
                className="text-[11.5px] text-[#0A0A0A] font-semibold hover:underline cursor-pointer"
              >
                फिल्टर साफ करा
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-[#6E6E6E] mb-0.5">
                दिनांक पासून (From Date):
              </label>
              <input
                type="date"
                value={pdfFrom}
                onChange={(e) => setPdfFrom(e.target.value)}
                className="w-full bg-white border border-[#9A9A9A] rounded-none px-2 py-1.5 text-[12.5px] text-[#0A0A0A] focus:outline-none focus:border-[#0A0A0A]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-[#6E6E6E] mb-0.5">
                दिनांक पर्यंत (To Date):
              </label>
              <input
                type="date"
                value={pdfTo}
                onChange={(e) => setPdfTo(e.target.value)}
                className="w-full bg-white border border-[#9A9A9A] rounded-none px-2 py-1.5 text-[12.5px] text-[#0A0A0A] focus:outline-none focus:border-[#0A0A0A]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-[#6E6E6E] mb-0.5">
                गाव / कार्यक्षेत्र (Village Filter):
              </label>
              <select
                value={pdfVillage}
                onChange={(e) => setPdfVillage(e.target.value)}
                className="w-full bg-white border border-[#9A9A9A] rounded-none px-2 py-1.5 text-[12.5px] text-[#0A0A0A] focus:outline-none focus:border-[#0A0A0A] cursor-pointer"
              >
                <option value="">सर्व गावे (एकत्रित अहवाल)</option>
                {allVillages.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* ACTIVE FILTER STATUS PILL */}
          <div className="mt-2 pt-2 border-t border-[#E0DED6] flex items-center justify-between text-[11.5px] text-[#6E6E6E] flex-wrap gap-1">
            <div>
              कालावधी: <b className="text-[#0A0A0A]">{dateRangeDisplay}</b>
              {pdfVillage && <span className="ml-2 font-semibold text-[#0A0A0A]">• गाव: {pdfVillage}</span>}
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#1E7B34] bg-[#EAF5EC] px-2 py-0.5 rounded-none border border-[#1E7B34]/30">
                तपासलेली घरे: {activeTotals.housesInsp} | कंटेनर: {activeTotals.contInsp} | नोंदी: {activeRecords.length}
              </span>
            </div>
          </div>
        </div>

        {/* PRINTABLE REPORT CONTAINER */}
        <div className="overflow-y-auto p-6 md:p-8 bg-white flex-1 text-[#0A0A0A]" id="official-report-printable">
          {/* TRICOLOR TOP BAR */}
          <div className="h-1.5 w-full bg-gradient-to-r from-[#0A0A0A] via-white to-[#1E7B34] mb-4 border border-[#F4F3EF]/30" />

          {/* OFFICIAL MAHARASHTRA GOVERNMENT LETTERHEAD */}
          <div className="text-center border-b-2 border-[#0A0A0A] pb-4 mb-4">
            <div className="flex items-center justify-center gap-3 mb-1">
              {/* Ashoka / Maharashtra Emblem Representation */}
              <div className="w-12 h-12 rounded-none border-2 border-[#0A0A0A] flex items-center justify-center bg-[#F4F3EF] text-[#0A0A0A] font-black text-[13px] ">
                <span>MH</span>
              </div>
              <div>
                <h1 className="text-[17px] md:text-[19px] font-extrabold text-[#0A0A0A] tracking-wide uppercase">
                  महाराष्ट्र शासन | GOVERNMENT OF MAHARASHTRA
                </h1>
                <h2 className="text-[15px] md:text-[16px] font-bold text-[#1E7B34]">
                  सार्वजनिक आरोग्य विभाग (Public Health Department)
                </h2>
              </div>
            </div>
            <div className="text-[13px] font-semibold text-[#6E6E6E]">
              राष्ट्रीय कीटकजन्य रोग नियंत्रण कार्यक्रम (NVBDCP)
            </div>
            <div className="inline-block mt-2 px-3 py-1 bg-[#ECEAE3] border border-[#0A0A0A] text-[#0A0A0A] font-bold text-[14px] rounded-none">
              कीटकशास्त्रीय सर्वेक्षण व डास अळी प्रतिबंधक तपासणी अहवाल
            </div>
          </div>

          {/* JURISDICTION & EMPLOYEE METADATA TABLE */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-3.5 bg-[#F4F3EF] border border-[#E0DED6] rounded-none text-[12.5px] mb-4">
            <div>
              <span className="text-[#6E6E6E] font-semibold block">जिल्हा:</span>
              <span className="font-bold text-[#0A0A0A]">{currentUser?.district || 'पुणे / महाराष्ट्र'}</span>
            </div>
            <div>
              <span className="text-[#6E6E6E] font-semibold block">तालुका:</span>
              <span className="font-bold text-[#0A0A0A]">{currentUser?.taluka || 'हवेली'}</span>
            </div>
            <div>
              <span className="text-[#6E6E6E] font-semibold block">प्रा. आ. केंद्र (PHC):</span>
              <span className="font-bold text-[#0A0A0A]">{currentUser?.phc || 'प्राथमिक आरोग्य केंद्र'}</span>
            </div>
            <div>
              <span className="text-[#6E6E6E] font-semibold block">उपकेंद्र (Sub-Center):</span>
              <span className="font-bold text-[#0A0A0A]">{currentUser?.subCenter || 'उपकेंद्र'}</span>
            </div>
            <div>
              <span className="text-[#6E6E6E] font-semibold block">कार्यक्षेत्र / गाव:</span>
              <span className="font-bold text-[#0A0A0A]">{pdfVillage || 'सर्व कार्यक्षेत्र गावे'}</span>
            </div>
            <div>
              <span className="text-[#6E6E6E] font-semibold block">अहवाल कालावधी:</span>
              <span className="font-bold text-[#0A0A0A]">{dateRangeDisplay}</span>
            </div>
            <div className="col-span-2">
              <span className="text-[#6E6E6E] font-semibold block">सर्वेक्षण कर्मचारी:</span>
              <span className="font-bold text-[#0A0A0A]">
                {currentUser ? `${currentUser.name} (${currentUser.designation || 'आरोग्य सेवक'}, आयडी: ${currentUser.employeeId || '-'})` : 'आरोग्य कर्मचारी'}
              </span>
            </div>
          </div>

          {/* KEY INDICES SECTION (CALCULATED FOR THE DATE RANGE) */}
          <div className="mb-4">
            <div className="text-[13px] font-extrabold text-[#0A0A0A] uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>कालावधीनुसार कीटकशास्त्रीय निर्देशांक (Vector Indices for Period)</span>
              <span
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-none"
                style={{ backgroundColor: risk.bgColor, color: risk.color }}
              >
                {risk.text}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div className="border border-[#E0DED6] p-3 rounded-none bg-white text-center ">
                <div className="text-[12px] font-bold text-[#6E6E6E]">हाऊस इंडेक्स (HI)</div>
                <div className="text-[22px] font-extrabold text-[#0A0A0A] mt-0.5">
                  {activeTotals.hi.toFixed(1)}%
                </div>
                <div className="text-[10px] text-[#6E6E6E] mt-0.5">
                  {activeTotals.housesPos} पॉझिटिव्ह ÷ {activeTotals.housesInsp} घरे
                </div>
                <div className="text-[9.5px] text-[#9A9A9A]">मानक मर्यादा: &lt; 1%</div>
              </div>

              <div className="border border-[#E0DED6] p-3 rounded-none bg-white text-center ">
                <div className="text-[12px] font-bold text-[#6E6E6E]">कंटेनर इंडेक्स (CI)</div>
                <div className="text-[22px] font-extrabold text-[#0A0A0A] mt-0.5">
                  {activeTotals.ci.toFixed(1)}%
                </div>
                <div className="text-[10px] text-[#6E6E6E] mt-0.5">
                  {activeTotals.contPos} पॉझिटिव्ह ÷ {activeTotals.contInsp} कंटेनर
                </div>
                <div className="text-[9.5px] text-[#9A9A9A]">मानक मर्यादा: &lt; 1%</div>
              </div>

              <div className="border border-[#E0DED6] p-3 rounded-none bg-white text-center ">
                <div className="text-[12px] font-bold text-[#6E6E6E]">ब्रेटो इंडेक्स (BI)</div>
                <div className="text-[22px] font-extrabold text-[#0A0A0A] mt-0.5">
                  {activeTotals.bi.toFixed(1)}
                </div>
                <div className="text-[10px] text-[#6E6E6E] mt-0.5">
                  {activeTotals.contPos} पॉझिटिव्ह कंटेनर ÷ १०० घरे
                </div>
                <div className="text-[9.5px] text-[#9A9A9A]">मानक मर्यादा: &lt; 5</div>
              </div>
            </div>

            <div className="mt-2 text-[11.5px] p-2 bg-[#F4F3EF] rounded-none border border-[#E0DED6] text-[#6E6E6E]">
              <b className="text-[#0A0A0A]">मार्गदर्शन शेरा:</b> {risk.desc}
            </div>
          </div>

          {/* DETAILED SURVEY DATA TABLE */}
          <div className="mb-5">
            <div className="text-[13px] font-extrabold text-[#0A0A0A] uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>तपासणी तपशील तक्ता ({activeRecords.length} नोंदी)</span>
              <span className="text-[11px] font-semibold text-[#6E6E6E]">
                {dateRangeDisplay}
              </span>
            </div>
            <div className="overflow-x-auto border border-[#E0DED6] rounded-none">
              <table className="w-full text-[11.5px] border-collapse text-left">
                <thead>
                  <tr className="bg-[#0A0A0A] text-white">
                    <th className="p-2 border-r border-[#0A0A0A] text-center w-10">अ.क्र.</th>
                    <th className="p-2 border-r border-[#0A0A0A]">दिनांक</th>
                    <th className="p-2 border-r border-[#0A0A0A]">गाव</th>
                    <th className="p-2 border-r border-[#0A0A0A]">कुटुंबप्रमुख</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">घरे</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">पॉझिटिव्ह</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">कंटेनर</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">पॉझि. कंटेनर</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">रिकामे</th>
                    <th className="p-2 border-r border-[#0A0A0A] text-center">अॅबेट</th>
                    <th className="p-2">शेरा</th>
                  </tr>
                </thead>
                <tbody>
                  {activeRecords.length === 0 ? (
                    <tr>
                      <td colSpan={11} className="p-4 text-center text-[#6E6E6E]">
                        निवडलेल्या कालावधीत ({dateRangeDisplay}) कोणतीही नोंद उपलब्ध नाही.
                      </td>
                    </tr>
                  ) : (
                    activeRecords.map((r, idx) => (
                      <tr
                        key={r.id}
                        className={idx % 2 === 0 ? 'bg-white' : 'bg-[#F4F6F9]'}
                      >
                        <td className="p-2 border-t border-r border-[#E0DED6] text-center font-bold">
                          {idx + 1}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6] whitespace-nowrap font-medium">
                          {formatIndianDate(r.date)}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6]">{r.village}</td>
                        <td className="p-2 border-t border-r border-[#E0DED6] font-semibold text-[#0A0A0A]">
                          {r.head}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6] text-center">
                          {r.housesInspected}
                        </td>
                        <td className={`p-2 border-t border-r border-[#D9E2EC] text-center font-bold ${r.housesPositive > 0 ? 'text-[#BA2525] bg-[#FDE8E8]/50' : 'text-[#107C41]'}`}>
                          {r.housesPositive}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6] text-center">
                          {r.containersInspected}
                        </td>
                        <td className={`p-2 border-t border-r border-[#D9E2EC] text-center font-bold ${r.containersPositive > 0 ? 'text-[#BA2525] bg-[#FDE8E8]/50' : 'text-[#107C41]'}`}>
                          {r.containersPositive}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6] text-center">
                          {r.containersEmptied}
                        </td>
                        <td className="p-2 border-t border-r border-[#E0DED6] text-center font-bold">
                          {r.abate ? 'होय' : 'नाही'}
                        </td>
                        <td className="p-2 border-t border-[#E0DED6] text-[#6E6E6E] max-w-[140px] truncate">
                          {r.notes || '-'}
                        </td>
                      </tr>
                    ))
                  )}
                  {/* TOTALS SUMMARY ROW DYNAMICALLY MATCHING DATES */}
                  <tr className="bg-[#ECEAE3] font-bold text-[#0A0A0A] border-t-2 border-[#0A0A0A]">
                    <td colSpan={4} className="p-2.5 text-right pr-3 border-r border-[#E0DED6]">
                      कालावधी एकूण बेरीज (Period Totals):
                    </td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6]">{activeTotals.housesInsp}</td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6] text-[#B3261E]">{activeTotals.housesPos}</td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6]">{activeTotals.contInsp}</td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6] text-[#B3261E]">{activeTotals.contPos}</td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6]">{activeTotals.contEmpty}</td>
                    <td className="p-2.5 text-center border-r border-[#E0DED6] text-[#1E7B34]">{activeTotals.abate}</td>
                    <td className="p-2.5">-</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* ACTION UNDERTAKEN NOTE */}
          <div className="p-3 bg-[#EAF5EC] border border-[#1E7B34]/30 rounded-none text-[11.5px] text-[#1E7B34] mb-6">
            <span className="font-bold">केलेली प्रतिबंधक कार्यवाही:</span> आढळलेल्या पॉझिटिव्ह कंटेनर्समधील पाणी रिकामे करून अळ्या नष्ट करण्यात आल्या. गरज असलेल्या पाण्याच्या टाक्यांमध्ये टेमिफॉस (अॅबेट १%) द्रावण विहित प्रमाणात टाकण्यात आले असून नागरिकांना आठवड्यातून एक दिवस 'कोरडा दिवस' पाळण्याचा सल्ला देण्यात आला.
          </div>

          {/* SIGNATURES BLOCK */}
          <div className="grid grid-cols-3 gap-6 pt-6 border-t border-[#E0DED6] text-[12px] text-center">
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-[#6E6E6E] pt-1">
                <div className="font-bold text-[#0A0A0A]">स्वाक्षरी सर्वेक्षक</div>
                <div className="text-[11px] text-[#6E6E6E]">(आरोग्य सेवक / सेविका / MPW)</div>
              </div>
            </div>

            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-[#6E6E6E] pt-1">
                <div className="font-bold text-[#0A0A0A]">स्वाक्षरी पर्यवेक्षक</div>
                <div className="text-[11px] text-[#6E6E6E]">(आरोग्य सहाय्यक / HA)</div>
              </div>
            </div>

            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-[#6E6E6E] pt-1">
                <div className="font-bold text-[#0A0A0A]">वैद्यकीय अधिकारी</div>
                <div className="text-[11px] text-[#6E6E6E]">(स्वाक्षरी व कार्यालयीन शिक्का)</div>
              </div>
            </div>
          </div>

          {/* BOTTOM OFFICIAL WATERMARK */}
          <div className="text-center text-[10px] text-[#9A9A9A] mt-6">
            सार्वजनिक आरोग्य विभाग, महाराष्ट्र शासन • राष्ट्रीय कीटकजन्य रोग नियंत्रण कार्यक्रम (NVBDCP) • संगणकीय जनरेटेड अहवाल
          </div>
        </div>
      </div>
    </div>
  );
};
