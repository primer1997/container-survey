import React, { useEffect } from 'react';
import { UserProfile } from '../types';

interface EntryState {
  members: number;
  housesInspected: number;
  containersInspected: number;
  containersPositive: number;
  containersEmptied: number;
  abate: boolean;
  houseStatusOverride: boolean | null;
}

interface EntryTabProps {
  date: string;
  setDate: (d: string) => void;
  village: string;
  setVillage: (v: string) => void;
  head: string;
  setHead: (h: string) => void;
  notes: string;
  setNotes: (n: string) => void;
  entryState: EntryState;
  setEntryState: React.Dispatch<React.SetStateAction<EntryState>>;
  editingId: string | null;
  onCancelEdit: () => void;
  onSave: () => void;
  villages: string[];
  currentUser?: UserProfile | null;
}

function Stepper({
  value,
  onChange,
  danger,
}: {
  value: number;
  onChange: (dir: number) => void;
  danger?: boolean;
}) {
  const btn = danger
    ? 'bg-[#FBEDEB] hover:bg-[#B3261E] text-[#B3261E] hover:text-white'
    : 'bg-[#F4F3EF] hover:bg-[#0A0A0A] text-[#0A0A0A] hover:text-white';
  const num = danger ? 'text-[#B3261E]' : 'text-[#0A0A0A]';
  return (
    <div
      className={`flex items-stretch justify-between border overflow-hidden bg-white ${
        danger ? 'border-[#B3261E]' : 'border-[#0A0A0A]'
      }`}
    >
      <button
        type="button"
        onClick={() => onChange(-1)}
        className={`w-12 h-12 ${btn} text-xl font-bold cursor-pointer transition-colors border-r ${
          danger ? 'border-[#B3261E]/30' : 'border-[#0A0A0A]/20'
        }`}
        aria-label="कमी करा"
      >
        −
      </button>
      <div className={`flex-1 self-center text-center text-xl font-black ${num}`}>
        {value}
      </div>
      <button
        type="button"
        onClick={() => onChange(1)}
        className={`w-12 h-12 ${btn} text-xl font-bold cursor-pointer transition-colors border-l ${
          danger ? 'border-[#B3261E]/30' : 'border-[#0A0A0A]/20'
        }`}
        aria-label="वाढवा"
      >
        +
      </button>
    </div>
  );
}

export const EntryTab: React.FC<EntryTabProps> = ({
  date,
  setDate,
  village,
  setVillage,
  head,
  setHead,
  notes,
  setNotes,
  entryState,
  setEntryState,
  editingId,
  onCancelEdit,
  onSave,
  villages,
  currentUser,
}) => {
  // If village is empty, pre-fill with user's primary assigned village
  useEffect(() => {
    if (!village && currentUser) {
      if (currentUser.village) {
        setVillage(currentUser.village);
      } else if (currentUser.assignedVillages && currentUser.assignedVillages.length > 0) {
        setVillage(currentUser.assignedVillages[0]);
      }
    }
  }, [currentUser, village, setVillage]);
  // Compute house status
  const autoPositive = entryState.containersPositive > 0;
  const isHousePositive =
    entryState.houseStatusOverride === null
      ? autoPositive
      : entryState.houseStatusOverride;

  const handleStepperChange = (key: keyof EntryState, dir: number, min: number = 0) => {
    setEntryState((prev) => {
      const currentVal = Number(prev[key]) || 0;
      let nextVal = currentVal + dir;
      if (nextVal < min) nextVal = min;

      const updated = { ...prev, [key]: nextVal };

      // Constraints: containersPositive cannot exceed containersInspected
      if (key === 'containersPositive' && nextVal > updated.containersInspected) {
        updated.containersPositive = updated.containersInspected;
      }
      if (key === 'containersInspected' && updated.containersPositive > nextVal) {
        updated.containersPositive = nextVal;
      }

      return updated;
    });
  };

  const handleToggleHouseStatus = () => {
    setEntryState((prev) => {
      const auto = prev.containersPositive > 0;
      const current = prev.houseStatusOverride === null ? auto : prev.houseStatusOverride;
      return {
        ...prev,
        houseStatusOverride: !current,
      };
    });
  };

  const handleToggleAbate = () => {
    setEntryState((prev) => ({
      ...prev,
      abate: !prev.abate,
    }));
  };

  return (
    <section id="page-entry" className="w-full">
      {/* EDITING INDICATOR */}
      {editingId && (
        <div className="bg-[#FBF3DF] border border-[#0A0A0A] p-2.5 mb-4 flex items-center justify-between">
          <span className="mono-label text-[#0A0A0A]">नोंद संपादन मोड — EDITING</span>
          <button
            type="button"
            onClick={onCancelEdit}
            className="mono-label-sm underline underline-offset-2 cursor-pointer"
          >
            रद्द करा
          </button>
        </div>
      )}

      {/* 01 — HOUSE & FAMILY */}
      <div className="rule-card p-4 mb-4">
        <div className="section-eyebrow">
          <span className="num">01</span>
          <span className="mono-label">भेट व कुटुंबप्रमुखाचा तपशील</span>
          <span className="rule"></span>
        </div>

        {/* WORKER JURISDICTION */}
        {currentUser && (currentUser.phc || currentUser.subCenter) && (
          <div className="border border-[#0A0A0A]/25 bg-[#F4F3EF] text-[12px] px-3 py-2 mb-4 flex items-center justify-between flex-wrap gap-1">
            <span className="text-[#6E6E6E]">
              <b className="text-[#0A0A0A]">कार्यक्षेत्र:</b> {currentUser.phc}{' '}
              {currentUser.subCenter ? `• ${currentUser.subCenter}` : ''}
            </span>
            {currentUser.village && (
              <span className="mono-label-sm border border-[#0A0A0A]/25 px-2 py-0.5">
                मुख्यालय: {currentUser.village}
              </span>
            )}
          </div>
        )}

        <div className="mb-4">
          <label htmlFor="f-date" className="field-label">
            भेटीचा दिनांक (Date of Survey) *
          </label>
          <input
            type="date"
            id="f-date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="field"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="f-village" className="field-label">
            गाव / वस्ती / वार्ड (Village / Ward) *
          </label>

          {currentUser?.assignedVillages && currentUser.assignedVillages.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 mb-2">
              <span className="mono-label-sm text-[#6E6E6E]">कार्यक्षेत्रातील गावे:</span>
              {currentUser.assignedVillages.map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setVillage(v)}
                  className={`mono-label-sm px-2.5 py-1 border transition-colors cursor-pointer ${
                    village === v
                      ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                      : 'bg-transparent text-[#0A0A0A] border-[#0A0A0A]/30 hover:border-[#0A0A0A]'
                  }`}
                >
                  {v} {village === v ? '✓' : ''}
                </button>
              ))}
            </div>
          )}

          <input
            type="text"
            id="f-village"
            list="village-list"
            value={village}
            onChange={(e) => setVillage(e.target.value)}
            placeholder="उदा. कोंडापूर, वार्ड क्र. २"
            className="field"
          />
          <datalist id="village-list">
            {villages.map((v) => (
              <option key={v} value={v} />
            ))}
          </datalist>
        </div>

        <div className="mb-4">
          <label htmlFor="f-head" className="field-label">
            कुटुंबप्रमुखाचे नाव (Head of Household) *
          </label>
          <input
            type="text"
            id="f-head"
            value={head}
            onChange={(e) => setHead(e.target.value)}
            placeholder="उदा. श्री. आनंदराव पाटील"
            className="field"
          />
        </div>

        <div>
          <label className="field-label">कुटुंबातील एकूण सदस्य संख्या (Members)</label>
          <Stepper value={entryState.members} onChange={(d) => handleStepperChange('members', d, 0)} />
        </div>
      </div>

      {/* 02 — LARVAL INSPECTION */}
      <div className="rule-card p-4 mb-4">
        <div className="section-eyebrow">
          <span className="num">02</span>
          <span className="mono-label">कंटेनर व डास अळी तपासणी</span>
          <span className="rule"></span>
        </div>

        <div className="mb-4">
          <label className="field-label">या भेटीत तपासलेली घरे (Houses Inspected)</label>
          <Stepper
            value={entryState.housesInspected}
            onChange={(d) => handleStepperChange('housesInspected', d, 1)}
          />
          <div className="text-[11px] text-[#9A9A9A] mt-1">
            साधारणपणे १ घर (एकापेक्षा जास्त कुटुंब/वाडा असल्यास संख्या वाढवा)
          </div>
        </div>

        <div className="mb-4">
          <label className="field-label">तपासलेले एकूण कंटेनर (Containers Inspected)</label>
          <Stepper
            value={entryState.containersInspected}
            onChange={(d) => handleStepperChange('containersInspected', d, 0)}
          />
          <div className="text-[11px] text-[#9A9A9A] mt-1">
            पाण्याच्या टाक्या, हौद, कुलर, ड्रम, कुंड्या, टायर, नारळाच्या करवंट्या इत्यादी
          </div>
        </div>

        <div className="mb-4">
          <label className="field-label !text-[#B3261E] flex items-center justify-between">
            <span>डास अळी आढळलेले (पॉझिटिव्ह) कंटेनर *</span>
            <span className="mono-label-sm">अळ्या आढळल्यास वाढवा</span>
          </label>
          <Stepper
            danger
            value={entryState.containersPositive}
            onChange={(d) => handleStepperChange('containersPositive', d, 0)}
          />
        </div>

        <div>
          <label className="field-label">घराची प्रादुर्भाव स्थिती (House Index Status)</label>
          <div
            id="houseStatusBadge"
            onClick={handleToggleHouseStatus}
            className={`flex items-center justify-between p-3 font-bold text-[14px] border cursor-pointer select-none transition-colors ${
              isHousePositive
                ? 'bg-[#FBEDEB] text-[#B3261E] border-[#B3261E]'
                : 'bg-[#EAF5EC] text-[#1E7B34] border-[#1E7B34]'
            }`}
          >
            <span className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 ${isHousePositive ? 'bg-[#B3261E]' : 'bg-[#1E7B34]'}`}
              ></span>
              <span>{isHousePositive ? 'पॉझिटिव्ह घर (डास अळी उपस्थित)' : 'निगेटिव्ह घर (स्वच्छ / अळीमुक्त)'}</span>
            </span>
            <span className="mono-label-sm underline underline-offset-2 opacity-80">स्थिती बदला</span>
          </div>
        </div>
      </div>

      {/* 03 — ACTION TAKEN */}
      <div className="rule-card p-4 mb-4">
        <div className="section-eyebrow">
          <span className="num">03</span>
          <span className="mono-label">प्रतिबंधक उपाययोजना</span>
          <span className="rule"></span>
        </div>

        <div className="mb-4">
          <div
            id="abateRow"
            onClick={handleToggleAbate}
            className="flex items-center justify-between border border-[#0A0A0A] p-3 cursor-pointer select-none bg-white hover:bg-[#F4F3EF] transition-colors"
          >
            <div>
              <span className="text-[14px] font-bold text-[#0A0A0A] block">
                अबेट (Temephos 1%) रासायनिक उपचार केले
              </span>
              <span className="text-[11px] text-[#6E6E6E]">
                मोठ्या पाण्याच्या टाक्या व हौदामध्ये विहित प्रमाणात कीटकनाशक टाकले
              </span>
            </div>
            <div
              id="abateSwitch"
              className={`relative w-12 h-7 border transition-colors shrink-0 ml-2 ${
                entryState.abate ? 'bg-[#0A0A0A] border-[#0A0A0A]' : 'bg-white border-[#0A0A0A]/40'
              }`}
            >
              <div
                className={`absolute top-0.5 w-5 h-5 transition-all ${
                  entryState.abate ? 'left-[24px] bg-white' : 'left-0.5 bg-[#0A0A0A]/40'
                }`}
              />
            </div>
          </div>
        </div>

        <div>
          <label className="field-label">रिकामे / नष्ट केलेले दूषित कंटेनर (Emptied / Destroyed)</label>
          <Stepper
            value={entryState.containersEmptied}
            onChange={(d) => handleStepperChange('containersEmptied', d, 0)}
          />
          <div className="text-[11px] text-[#9A9A9A] mt-1">
            'कोरडा दिवस' अंतर्गत पाणी ओतून स्वच्छ केलेले भांडे
          </div>
        </div>
      </div>

      {/* 04 — REMARKS */}
      <div className="rule-card p-4 mb-4">
        <div className="section-eyebrow">
          <span className="num">04</span>
          <span className="mono-label">शेरा / विशेष निरीक्षण</span>
          <span className="rule"></span>
        </div>
        <div>
          <label htmlFor="f-notes" className="field-label">
            शेरा / विशेष निरीक्षण (Remarks)
          </label>
          <textarea
            id="f-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="उदा. कुलर स्वच्छ केला, नागरिकांना कोरडा दिवस पाळण्याचे समुपदेशन केले..."
            rows={2}
            className="field resize-y min-h-[58px]"
          />
        </div>
      </div>

      {/* SAVE */}
      <div className="flex flex-col gap-2">
        <button id="saveBtn" type="button" onClick={onSave} className="btn-primary w-full !py-4 !text-[13px]">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
          </svg>
          {editingId ? 'नोंद अद्यतनित करा — UPDATE RECORD' : 'घराची नोंद जतन करा — SAVE RECORD'}
        </button>

        <div className="flex items-center justify-center gap-1.5 text-[11.5px] text-[#6E6E6E] font-medium mt-0.5">
          <svg className="w-3.5 h-3.5 text-[#1E7B34]" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>नोंद करताच स्थानिक रजिस्टरमध्ये आपोआप (Auto-save) सुरक्षित जतन होते</span>
        </div>

        {editingId && (
          <button
            type="button"
            onClick={onCancelEdit}
            className="btn-ghost w-full"
          >
            संपादन रद्द करा — CANCEL
          </button>
        )}
      </div>
    </section>
  );
};
