import React from 'react';

export type ActiveTab = 'entry' | 'records' | 'summary';

interface TabBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
}

const tabs: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
  {
    id: 'entry',
    label: 'नवीन नोंद',
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <path d="M12 5v14M5 12h14" />
      </svg>
    ),
  },
  {
    id: 'records',
    label: 'तपासणी नोंदी',
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
      </svg>
    ),
  },
  {
    id: 'summary',
    label: 'निर्देशांक व अहवाल',
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
  },
];

export const TabBar: React.FC<TabBarProps> = ({ activeTab, onSelectTab }) => {
  return (
    <nav
      id="bottom-tabbar"
      className="fixed bottom-0 left-0 right-0 z-30 bg-[#F4F3EF] border-t border-[#0A0A0A] px-2 pt-2 pb-[calc(8px+env(safe-area-inset-bottom))]"
    >
      <div className="max-w-[620px] mx-auto w-full flex gap-1.5">
        {tabs.map((t) => {
          const active = activeTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              data-tab={t.id}
              onClick={() => onSelectTab(t.id)}
              className={`flex-1 border py-2 px-1 cursor-pointer flex flex-col items-center gap-1 transition-colors ${
                active
                  ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                  : 'bg-transparent text-[#6E6E6E] border-transparent hover:text-[#0A0A0A] hover:border-[#0A0A0A]/30'
              }`}
            >
              {t.icon}
              <span className="mono-label-sm">{t.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
