import React from 'react';
import { UserProfile } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  statusText: string;
  dateSub: string;
  currentUser: UserProfile | null;
  onLogout: () => void;
  onOpenAuth: () => void;
  onEditProfile?: () => void;
  onOpenPdfReport?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  statusText,
  dateSub,
  currentUser,
  onLogout,
  onOpenAuth,
  onEditProfile,
  onOpenPdfReport,
}) => {
  const saving = statusText.includes('करत आहे');
  return (
    <header id="app-header" className="sticky top-0 z-20 bg-[#0A0A0A] text-white">
      <div className="max-w-[620px] mx-auto px-4 pt-3 pb-3">
        {/* TOP META ROW */}
        <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-white/15">
          <div className="mono-label-sm text-white/60">
            महाराष्ट्र शासन • सार्वजनिक आरोग्य विभाग
          </div>
          <span
            id="statusText"
            className={`mono-label-sm px-2 py-0.5 border flex items-center gap-1.5 shrink-0 ${
              saving
                ? 'border-[#8A5A00] text-[#E8C15A] bg-transparent'
                : 'border-white/25 text-white/85 bg-transparent'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 ${saving ? 'bg-[#E8C15A]' : 'bg-white'}`}
            ></span>
            {statusText}
          </span>
        </div>

        {/* TITLE ROW */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="display text-[22px] md:text-[24px] text-white m-0">
              कंटेनर सर्वेक्षण
            </h1>
            <div id="dateSub" className="mono-label-sm text-white/50 mt-1">
              {dateSub} • NVBDCP
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
            <PWAInstallButton />
            {onOpenPdfReport && (
              <button
                type="button"
                onClick={onOpenPdfReport}
                className="bg-white text-black hover:bg-[#F4F3EF] mono-label-sm px-2 py-1.5 flex items-center gap-1 transition-colors cursor-pointer"
                title="शासकीय PDF अहवाल"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span>PDF अहवाल</span>
              </button>
            )}
          </div>
        </div>

        {/* USER ROW */}
        {currentUser ? (
          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-white/15 gap-2 flex-wrap">
            <div id="userInfo" className="flex items-center gap-x-2 gap-y-1 flex-wrap text-[12px]">
              <span className="font-bold text-white">{currentUser.name}</span>
              <span className="mono-label-sm text-white/50">
                {currentUser.designation || 'आरोग्य सेवक'}
              </span>
              {currentUser.phc && (
                <span className="mono-label-sm text-white/70 border border-white/20 px-1.5 py-px">
                  {currentUser.phc}
                </span>
              )}
              {currentUser.village && (
                <span className="mono-label-sm text-white/70">
                  गाव: {currentUser.village}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {onEditProfile && (
                <button
                  id="editProfileBtn"
                  type="button"
                  onClick={onEditProfile}
                  className="text-white/70 hover:text-white mono-label-sm underline underline-offset-2 cursor-pointer"
                  title="स्वतःची माहिती व कार्यक्षेत्र संपादन करा"
                >
                  माहिती संपादन
                </button>
              )}
              <button
                id="switchWorkerBtn"
                type="button"
                onClick={onOpenAuth}
                className="text-white/70 hover:text-white mono-label-sm underline underline-offset-2 cursor-pointer"
                title="दुसऱ्या कर्मचाऱ्याचे खाते निवडा किंवा नवीन नोंदणी करा"
              >
                कर्मचारी बदला
              </button>
              <button
                id="logoutBtn"
                type="button"
                onClick={onLogout}
                className="text-white/70 hover:text-white mono-label-sm underline underline-offset-2 cursor-pointer"
              >
                लॉगआउट
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-white/15">
            <span className="mono-label-sm text-white/50">कर्मचारी लॉगिन केलेले नाही</span>
            <button
              type="button"
              onClick={onOpenAuth}
              className="bg-white text-black mono-label-sm px-2.5 py-1.5 cursor-pointer"
            >
              लॉगिन / नोंदणी
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
