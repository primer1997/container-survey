import React, { useState, useMemo } from 'react';
import { SurveyRecord, UserProfile } from '../types';
import { calculateTotals, exportToCSV, formatIndianDate, todayStr } from '../utils/storage';
import { getRiskLevel } from '../utils/pdfExport';

interface SummaryTabProps {
  records: SurveyRecord[];
  villages: string[];
  currentUser: UserProfile | null;
  onOpenPdfReport: (filter?: { from: string; to: string; village: string }) => void;
  showToast: (msg: string) => void;
}

function IndexCard({
  name,
  latin,
  formula,
  limit,
  value,
  suffix,
  id,
}: {
  name: string;
  latin: string;
  formula: string;
  limit: string;
  value: string;
  suffix?: string;
  id: string;
}) {
  return (
    <div className="rule-card p-4">
      <div className="flex justify-between items-start gap-2">
        <div>
          <div className="text-[14px] font-extrabold text-[#0A0A0A] tracking-tight">
            {name} <span className="mono-label-sm text-[#9A9A9A]">{latin}</span>
          </div>
          <div className="text-[11.5px] text-[#6E6E6E] mt-0.5">{formula}</div>
        </div>
        <span className="mono-label-sm px-2 py-0.5 border border-[#0A0A0A]/25 text-[#6E6E6E] whitespace-nowrap">
          {limit}
        </span>
      </div>
      <div id={id} className="display text-[34px] text-[#0A0A0A] mt-1.5 leading-none">
        {value}
        {suffix && <span className="text-[18px] font-bold text-[#6E6E6E] ml-1">{suffix}</span>}
      </div>
    </div>
  );
}

function TotalCell({
  id,
  value,
  label,
  tone,
}: {
  id: string;
  value: number;
  label: string;
  tone?: 'danger' | 'ok' | 'plain';
}) {
  const color =
    tone === 'danger' ? 'text-[#B3261E]' : tone === 'ok' ? 'text-[#1E7B34]' : 'text-[#0A0A0A]';
  return (
    <div className="bg-white border border-[#0A0A0A]/25 p-3">
      <div id={id} className={`display text-[24px] ${color}`}>
        {value}
      </div>
      <div className="mono-label-sm text-[#9A9A9A] mt-1">{label}</div>
    </div>
  );
}

export const SummaryTab: React.FC<SummaryTabProps> = ({
  records,
  villages,
  currentUser,
  onOpenPdfReport,
  showToast,
}) => {
  const [sumFrom, setSumFrom] = useState('');
  const [sumTo, setSumTo] = useState('');
  const [sumVillage, setSumVillage] = useState('');

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      if (sumFrom && r.date < sumFrom) return false;
      if (sumTo && r.date > sumTo) return false;
      if (sumVillage && r.village !== sumVillage) return false;
      return true;
    });
  }, [records, sumFrom, sumTo, sumVillage]);

  const totals = useMemo(() => {
    return calculateTotals(filteredRecords);
  }, [filteredRecords]);

  const risk = getRiskLevel(totals.hi, totals.ci, totals.bi);

  // Formatted date period description
  const displayPeriodText = useMemo(() => {
    if (sumFrom && sumTo) {
      if (sumFrom === sumTo) {
        return `${formatIndianDate(sumFrom)} (आजचा दैनिक अहवाल)`;
      }
      return `${formatIndianDate(sumFrom)} ते ${formatIndianDate(sumTo)}`;
    }
    if (sumFrom) return `${formatIndianDate(sumFrom)} नंतरच्या नोंदी`;
    if (sumTo) return `${formatIndianDate(sumTo)} पर्यंतच्या नोंदी`;
    return 'सर्व नोंदी (एकत्रित कालावधी)';
  }, [sumFrom, sumTo]);

  const isFiltered = Boolean(sumFrom || sumTo || sumVillage);

  const handleExportCSV = () => {
    if (filteredRecords.length === 0) {
      showToast('निर्यात करण्यासाठी कोणतीही नोंद नाही');
      return;
    }
    exportToCSV(filteredRecords);
    showToast('CSV फाईल डाऊनलोड झाली');
  };

  const handleOpenPdfClick = () => {
    onOpenPdfReport({
      from: sumFrom,
      to: sumTo,
      village: sumVillage,
    });
  };

  return (
    <section id="page-summary" className="w-full">
      {/* TITLE BAND */}
      <div className="bg-[#0A0A0A] text-white p-4 mb-4">
        <div className="flex items-center justify-between gap-2">
          <span className="mono-label text-white">कीटकशास्त्रीय सर्वेक्षण — सारांश अहवाल</span>
          <span className="mono-label-sm text-white/60">
            {filteredRecords.length} / {records.length} नोंदी
          </span>
        </div>
      </div>

      {/* HEALTH WORKER CONTEXT */}
      {currentUser && (
        <div className="border border-[#0A0A0A]/25 bg-white p-2.5 mb-4 text-[12px] flex items-center justify-between text-[#6E6E6E] flex-wrap gap-1">
          <div>
            <b className="text-[#0A0A0A]">{currentUser.name}</b> ({currentUser.designation})
            <span className="mx-1.5">•</span>
            <span>{currentUser.phc}</span>
            {currentUser.subCenter && <span> • {currentUser.subCenter}</span>}
          </div>
          {currentUser.village && (
            <span className="mono-label-sm border border-[#0A0A0A]/25 px-2 py-0.5">
              मुख्यालय: {currentUser.village}
            </span>
          )}
        </div>
      )}

      {/* FILTER CARD */}
      <div className="rule-card p-4 mb-4">
        <div className="mono-label mb-3 flex items-center justify-between">
          <span>कालावधी व कार्यक्षेत्र फिल्टर</span>
          {isFiltered && (
            <button
              type="button"
              onClick={() => {
                setSumFrom('');
                setSumTo('');
                setSumVillage('');
              }}
              className="mono-label-sm underline underline-offset-2 cursor-pointer"
            >
              फिल्टर साफ करा
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 mb-2">
          <div>
            <label className="field-label !text-[11px]">दिनांक पासून (From Date)</label>
            <input
              type="date"
              id="sumFrom"
              value={sumFrom}
              onChange={(e) => setSumFrom(e.target.value)}
              className="field !p-2 !text-[13px]"
            />
          </div>
          <div>
            <label className="field-label !text-[11px]">दिनांक पर्यंत (To Date)</label>
            <input
              type="date"
              id="sumTo"
              value={sumTo}
              onChange={(e) => setSumTo(e.target.value)}
              className="field !p-2 !text-[13px]"
            />
          </div>
        </div>
        <div>
          <label className="field-label !text-[11px]">गाव / कार्यक्षेत्र</label>
          <select
            id="sumVillage"
            value={sumVillage}
            onChange={(e) => setSumVillage(e.target.value)}
            className="field !p-2 !text-[13px] cursor-pointer"
          >
            <option value="">सर्व गावे (एकत्रित अहवाल)</option>
            {villages.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* PERIOD NOTICE */}
      <div className="border border-[#0A0A0A] bg-white p-3 mb-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="text-[12px] font-bold text-[#0A0A0A]">
              कालावधी: <span className="font-black">{displayPeriodText}</span>
            </div>
            <div className="text-[11px] text-[#6E6E6E]">
              {filteredRecords.length > 0
                ? `या कालावधीतील ${filteredRecords.length} घरांच्या नोंदीनुसार खालील अहवाल व आकडेवारी अपडेट झाली आहे.`
                : 'या कालावधीत कोणतीही नोंद आढळली नाही. कृपया वेगळा दिनांक निवडा.'}
            </div>
          </div>
          <div className="mono-label-sm bg-[#0A0A0A] text-white px-2 py-1">
            {filteredRecords.length} नोंदी
          </div>
        </div>
      </div>

      {/* VECTOR RISK BANNER */}
      <div
        className="p-3.5 mb-4 border border-[#0A0A0A] flex items-start gap-3 bg-white"
      >
        <div className="w-7 h-7 flex items-center justify-center font-black text-white shrink-0 mt-0.5 text-sm bg-[#0A0A0A]">
          !
        </div>
        <div className="flex-1">
          <div className="mono-label text-[#0A0A0A]">
            प्रादुर्भाव पातळी: {risk.text}
          </div>
          <div className="text-[12px] text-[#6E6E6E] mt-1 leading-snug">{risk.desc}</div>
        </div>
      </div>

      {/* INDICES */}
      <div className="grid grid-cols-1 gap-3 mb-5">
        <IndexCard
          id="hiVal"
          name="हाऊस इंडेक्स (HI)"
          latin="HOUSE INDEX"
          formula={`पॉझिटिव्ह घरे (${totals.housesPos}) ÷ तपासलेली घरे (${totals.housesInsp}) × १००`}
          limit="मानक < 1%"
          value={totals.hi.toFixed(1)}
          suffix="%"
        />
        <IndexCard
          id="ciVal"
          name="कंटेनर इंडेक्स (CI)"
          latin="CONTAINER INDEX"
          formula={`पॉझिटिव्ह कंटेनर (${totals.contPos}) ÷ तपासलेले कंटेनर (${totals.contInsp}) × १००`}
          limit="मानक < 1%"
          value={totals.ci.toFixed(1)}
          suffix="%"
        />
        <IndexCard
          id="biVal"
          name="ब्रेटो इंडेक्स (BI)"
          latin="BRETEAU INDEX"
          formula={`पॉझिटिव्ह कंटेनर (${totals.contPos}) ÷ तपासलेली घरे (${totals.housesInsp}) × १००`}
          limit="मानक < 5"
          value={totals.bi.toFixed(1)}
        />
      </div>

      {/* TOTALS */}
      <div className="section-eyebrow">
        <span className="num">▪</span>
        <span className="mono-label">एकूण सर्वेक्षण आकडेवारी</span>
        <span className="rule"></span>
      </div>
      <div className="grid grid-cols-2 gap-2.5 mb-5">
        <TotalCell id="totHousesInsp" value={totals.housesInsp} label="तपासलेली घरे — HOUSES INSPECTED" />
        <TotalCell id="totHousesPos" value={totals.housesPos} label="पॉझिटिव्ह घरे — POSITIVE" tone="danger" />
        <TotalCell id="totContInsp" value={totals.contInsp} label="तपासलेले कंटेनर — CONTAINERS" />
        <TotalCell id="totContPos" value={totals.contPos} label="पॉझिटिव्ह कंटेनर — POSITIVE" tone="danger" />
        <TotalCell id="totContEmpty" value={totals.contEmpty} label="रिकामे केलेले — EMPTIED" />
        <TotalCell id="totAbate" value={totals.abate} label="अॅबेट उपचारित — ABATE" tone="ok" />
      </div>

      {/* EXPORT ACTIONS */}
      <div className="space-y-2.5 mb-6">
        <button
          id="openPdfBtn"
          type="button"
          onClick={handleOpenPdfClick}
          className="btn-primary w-full !py-4"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          शासकीय PDF अहवाल — VIEW & DOWNLOAD
        </button>

        <button
          id="exportBtn"
          type="button"
          onClick={handleExportCSV}
          className="btn-ghost w-full"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          CSV डेटा फाईल (Excel) निर्यात करा
        </button>
      </div>
    </section>
  );
};
