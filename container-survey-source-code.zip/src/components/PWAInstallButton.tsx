import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Share, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-none bg-[#0A0A0A] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#0A0A0A] transition"
      >
        <Download className="w-3.5 h-3.5" />
        Install App
      </button>
    );
  }

  // iOS Safari flow (beforeinstallprompt is not supported by WebKit)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-none border border-[#0A0A0A] px-3 py-1.5 text-xs font-semibold text-[#0A0A0A] hover:bg-[#ECEAE3] transition"
        >
          <Download className="w-3.5 h-3.5" />
          Install App
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
            <div className="w-full max-w-sm rounded-none bg-white p-5 relative animate-in fade-in zoom-in duration-200">
              <button 
                onClick={() => setShowIOSGuide(false)}
                className="absolute top-3 right-3 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
              
              <h3 className="text-[17px] font-bold text-slate-800 mb-1">Install on iPhone / iPad</h3>
              <p className="text-[13px] text-slate-500 mb-4">
                Add this app to your home screen for quick access and offline use.
              </p>
              
              <div className="space-y-4 bg-slate-50 p-4 rounded-none border border-slate-100">
                <div className="flex gap-3 text-[14px] text-slate-700 items-start">
                  <div className="w-6 h-6 rounded-none bg-white border border-slate-200 flex items-center justify-center shrink-0 mt-0.5">
                    <Share className="w-3.5 h-3.5 text-blue-500" />
                  </div>
                  <div>
                    Tap the <strong>Share</strong> button in the Safari toolbar at the bottom of the screen.
                  </div>
                </div>
                
                <div className="flex gap-3 text-[14px] text-slate-700 items-start">
                  <div className="w-6 h-6 rounded-none bg-white border border-slate-200 flex items-center justify-center shrink-0 mt-0.5 font-bold text-[12px] text-slate-500">
                    +
                  </div>
                  <div>
                    Scroll down and tap <strong>Add to Home Screen</strong>.
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-none bg-slate-900 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 transition"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
