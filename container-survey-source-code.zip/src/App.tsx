/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { SurveyRecord, UserProfile } from './types';
import {
  todayStr,
  getHeaderDateMarathi,
  USER_SESSION_KEY,
  getAllUsers,
  loadStoredRecords,
  saveStoredRecords,
  calculateTotals,
} from './utils/storage';
import { Header } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { EntryTab } from './components/EntryTab';
import { RecordsTab } from './components/RecordsTab';
import { SummaryTab } from './components/SummaryTab';
import { TabBar, ActiveTab } from './components/TabBar';
import { PdfReportModal } from './components/PdfReportModal';
import { SourceCodeModal } from './components/SourceCodeModal';

export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const raw = localStorage.getItem(USER_SESSION_KEY);
      if (raw) return JSON.parse(raw);
      // Default demo health worker user profile for seamless immediate inspection
      const defaultUser: UserProfile = {
        email: 'patya.mohite@gmail.com',
        name: 'पांडुरंग मोहिते',
        designation: 'आरोग्य सेवक / MPW',
        employeeId: 'MH-PHD-408',
        district: 'पुणे',
        taluka: 'हवेली',
        phc: 'प्रा.आ. केंद्र कोंढवा',
        subCenter: 'उपकेंद्र कोंडापूर',
      };
      localStorage.setItem(USER_SESSION_KEY, JSON.stringify(defaultUser));
      return defaultUser;
    } catch {
      return null;
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalInitialMode, setAuthModalInitialMode] = useState<'login' | 'register' | 'edit'>('login');
  const [userToEdit, setUserToEdit] = useState<UserProfile | null>(null);

  // Active Tab: 'entry' | 'records' | 'summary'
  const [activeTab, setActiveTab] = useState<ActiveTab>('entry');

  // PDF Report Modal State and Filter Configuration
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [isSourceCodeModalOpen, setIsSourceCodeModalOpen] = useState<boolean>(false);
  const [pdfFilterConfig, setPdfFilterConfig] = useState<{
    from: string;
    to: string;
    village: string;
  }>({
    from: '',
    to: '',
    village: '',
  });

  const handleOpenPdfReport = (filter?: { from?: string; to?: string; village?: string }) => {
    if (filter) {
      setPdfFilterConfig({
        from: filter.from ?? pdfFilterConfig.from,
        to: filter.to ?? pdfFilterConfig.to,
        village: filter.village ?? pdfFilterConfig.village,
      });
    }
    setIsPdfModalOpen(true);
  };

  // Survey Records State
  const [records, setRecords] = useState<SurveyRecord[]>([]);
  const [statusText, setStatusText] = useState<string>('प्रणाली सज्ज');

  // New/Edit Entry Form State
  const [date, setDate] = useState<string>(() => todayStr());
  const [village, setVillage] = useState<string>('');
  const [head, setHead] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [entryState, setEntryState] = useState({
    members: 4,
    housesInspected: 1,
    containersInspected: 4,
    containersPositive: 0,
    containersEmptied: 0,
    abate: false,
    houseStatusOverride: null as boolean | null,
  });
  const [editingId, setEditingId] = useState<string | null>(null);

  // Toast Notification State
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (msg: string) => {
    if (toastTimerRef.current) {
      clearTimeout(toastTimerRef.current);
    }
    setToastMessage(msg);
    toastTimerRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Load records whenever currentUser changes
  useEffect(() => {
    if (currentUser) {
      const loaded = loadStoredRecords(currentUser);
      setRecords(loaded);
    } else {
      setRecords([]);
    }
  }, [currentUser]);

  // Unique list of villages for datalists & filters
  const uniqueVillages = useMemo(() => {
    const set = new Set<string>();
    if (currentUser?.village) set.add(currentUser.village.trim());
    if (currentUser?.assignedVillages) {
      currentUser.assignedVillages.forEach((v) => set.add(v.trim()));
    }
    records.forEach((r) => {
      if (r.village) set.add(r.village.trim());
    });
    return Array.from(set)
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b, 'mr'));
  }, [records, currentUser]);

  // Overall totals
  const overallTotals = useMemo(() => {
    return calculateTotals(records);
  }, [records]);

  // Handle Login / Register success
  const handleAuthSuccess = (user: UserProfile) => {
    localStorage.setItem(USER_SESSION_KEY, JSON.stringify(user));
    setCurrentUser(user);
    if (user.village) {
      setVillage(user.village);
    }
    setIsAuthModalOpen(false);
  };

  // Open Auth Modal in standard login/switch mode
  const handleOpenAuth = () => {
    setUserToEdit(null);
    setAuthModalInitialMode('login');
    setIsAuthModalOpen(true);
  };

  // Open Auth Modal directly in Edit Mode for the current user
  const handleOpenEditProfile = () => {
    if (currentUser) {
      setUserToEdit(currentUser);
      setAuthModalInitialMode('edit');
      setIsAuthModalOpen(true);
    } else {
      handleOpenAuth();
    }
  };

  // Handle user details update
  const handleUserUpdated = (updatedUser: UserProfile) => {
    setCurrentUser(updatedUser);
    localStorage.setItem(USER_SESSION_KEY, JSON.stringify(updatedUser));
    if (updatedUser.village) {
      setVillage(updatedUser.village);
    }
    showToast(`'${updatedUser.name}' यांची माहिती अद्यतनित झाली.`);
  };

  // Handle employee deletion
  const handleUserDeleted = (deletedEmail: string) => {
    if (currentUser?.email === deletedEmail) {
      const remaining = Object.values(getAllUsers());
      if (remaining.length > 0) {
        const nextUser = remaining[0];
        setCurrentUser(nextUser);
        localStorage.setItem(USER_SESSION_KEY, JSON.stringify(nextUser));
        if (nextUser.village) {
          setVillage(nextUser.village);
        }
        showToast(`खाते हटवले. आता '${nextUser.name}' म्हणून लॉगिन झाले.`);
      } else {
        setCurrentUser(null);
        localStorage.removeItem(USER_SESSION_KEY);
        setRecords([]);
        setIsAuthModalOpen(true);
        showToast('कर्मचारी खाते हटवले.');
      }
    }
  };

  // Handle Logout
  const handleLogout = () => {
    if (window.confirm('आपल्या खात्यातून लॉगआउट करायचे आहे का?')) {
      localStorage.removeItem(USER_SESSION_KEY);
      setCurrentUser(null);
      setRecords([]);
      handleOpenAuth();
      showToast('लॉगआउट झाले');
    }
  };

  // Save or update survey record
  const handleSaveEntry = async () => {
    const trimmedHead = head.trim();
    const trimmedVillage = village.trim();

    if (!trimmedVillage) {
      showToast('गाव किंवा वस्तीचे नाव टाका');
      document.getElementById('f-village')?.focus();
      return;
    }
    if (!trimmedHead) {
      showToast('कुटुंबप्रमुखाचे नाव टाका');
      document.getElementById('f-head')?.focus();
      return;
    }

    setStatusText('जतन करत आहे...');

    const auto = entryState.containersPositive > 0;
    const isHousePos =
      entryState.houseStatusOverride === null ? auto : entryState.houseStatusOverride;
    const housePositiveCount = isHousePos ? entryState.housesInspected : 0;

    const newRecord: SurveyRecord = {
      id: editingId || 'REC-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
      date: date || todayStr(),
      village: trimmedVillage,
      subCenter: currentUser?.subCenter || '',
      phc: currentUser?.phc || '',
      head: trimmedHead,
      members: entryState.members,
      housesInspected: entryState.housesInspected,
      housesPositive: housePositiveCount,
      containersInspected: entryState.containersInspected,
      containersPositive: entryState.containersPositive,
      containersEmptied: entryState.containersEmptied,
      abate: entryState.abate,
      notes: notes.trim(),
    };

    let updatedRecords: SurveyRecord[];
    if (editingId) {
      updatedRecords = records.map((r) => (r.id === editingId ? newRecord : r));
    } else {
      updatedRecords = [newRecord, ...records];
    }

    setRecords(updatedRecords);
    saveStoredRecords(currentUser, updatedRecords);
    setStatusText('नोंद आपोआप जतन');

    showToast(editingId ? 'नोंद अद्यतनित व आपोआप जतन झाली' : 'नोंद आपोआप सुरक्षित जतन झाली');
    resetEntryForm();
  };

  const resetEntryForm = () => {
    setEditingId(null);
    setVillage('');
    setHead('');
    setNotes('');
    setDate(todayStr());
    setEntryState({
      members: 4,
      housesInspected: 1,
      containersInspected: 4,
      containersPositive: 0,
      containersEmptied: 0,
      abate: false,
      houseStatusOverride: null,
    });
  };

  // Populate record for editing
  const handleEditRecord = (rec: SurveyRecord) => {
    setEditingId(rec.id);
    setDate(rec.date);
    setVillage(rec.village);
    setHead(rec.head);
    setNotes(rec.notes || '');
    setEntryState({
      members: rec.members,
      housesInspected: rec.housesInspected,
      containersInspected: rec.containersInspected,
      containersPositive: rec.containersPositive,
      containersEmptied: rec.containersEmptied,
      abate: rec.abate,
      houseStatusOverride: rec.housesPositive > 0,
    });
    setActiveTab('entry');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Delete record
  const handleDeleteRecord = (id: string) => {
    const updated = records.filter((r) => r.id !== id);
    setRecords(updated);
    saveStoredRecords(currentUser, updated);
    showToast('शासकीय नोंद हटवण्यात आली');
  };

  const dateSub = getHeaderDateMarathi();

  return (
    <div className="min-h-screen pb-[80px] bg-[#F4F3EF] text-[#0A0A0A] font-sans antialiased selection:bg-[#0A0A0A] selection:text-white">
      {/* HEADER */}
      <Header
        statusText={statusText}
        dateSub={dateSub}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenAuth={handleOpenAuth}
        onEditProfile={handleOpenEditProfile}
        onOpenPdfReport={() => handleOpenPdfReport()}
        onOpenSourceCode={() => setIsSourceCodeModalOpen(true)}
      />

      {/* MAIN CONTENT CONTAINER */}
      <main id="mainContent" className="max-w-[620px] mx-auto p-3.5 md:p-4">
        {activeTab === 'entry' && (
          <EntryTab
            date={date}
            setDate={setDate}
            village={village}
            setVillage={setVillage}
            head={head}
            setHead={setHead}
            notes={notes}
            setNotes={setNotes}
            entryState={entryState}
            setEntryState={setEntryState}
            editingId={editingId}
            onCancelEdit={resetEntryForm}
            onSave={handleSaveEntry}
            villages={uniqueVillages}
            currentUser={currentUser}
          />
        )}

        {activeTab === 'records' && (
          <RecordsTab
            records={records}
            villages={uniqueVillages}
            onEdit={handleEditRecord}
            onDelete={handleDeleteRecord}
            onOpenPdfReport={handleOpenPdfReport}
          />
        )}

        {activeTab === 'summary' && (
          <SummaryTab
            records={records}
            villages={uniqueVillages}
            currentUser={currentUser}
            onOpenPdfReport={handleOpenPdfReport}
            showToast={showToast}
          />
        )}
      </main>

      {/* BOTTOM TABBAR */}
      <TabBar activeTab={activeTab} onSelectTab={setActiveTab} />

      {/* PDF REPORT PREVIEW & DOWNLOAD MODAL */}
      <PdfReportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        records={records}
        totals={overallTotals}
        currentUser={currentUser}
        selectedVillage={pdfFilterConfig.village}
        initialFromDate={pdfFilterConfig.from}
        initialToDate={pdfFilterConfig.to}
        dateRangeText={dateSub}
        showToast={showToast}
      />

      {/* SOURCE CODE & APK EXPORT MODAL */}
      <SourceCodeModal
        isOpen={isSourceCodeModalOpen}
        onClose={() => setIsSourceCodeModalOpen(false)}
      />

      {/* AUTH MODAL */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        initialMode={authModalInitialMode}
        userToEdit={userToEdit}
        onSuccess={handleAuthSuccess}
        onUserUpdated={handleUserUpdated}
        onUserDeleted={handleUserDeleted}
        showToast={showToast}
      />

      {/* TOAST NOTIFICATION */}
      {toastMessage && (
        <div
          id="toast"
          role="status"
          className="fixed bottom-[84px] left-1/2 -translate-x-1/2 bg-[#0A0A0A] text-white px-5 py-2.5 text-[12px] z-[60] max-w-[90%] text-center border border-[#0A0A0A] flex items-center gap-2"
        >
          <span className="w-2 h-2 bg-white shrink-0"></span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
