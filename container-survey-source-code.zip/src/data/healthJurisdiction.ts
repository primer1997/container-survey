/**
 * Maharashtra Public Health Department (सार्वजनिक आरोग्य विभाग)
 * Hierarchical Jurisdiction Directory: District -> Taluka -> PHC -> Sub-Center -> Villages
 */

export interface SubCenterItem {
  name: string;
  villages: string[];
}

export interface PhcItem {
  name: string;
  subCenters: SubCenterItem[];
}

export interface TalukaItem {
  name: string;
  phcs: PhcItem[];
}

export interface DistrictItem {
  name: string;
  talukas: TalukaItem[];
}

export const HEALTH_JURISDICTION_DATA: DistrictItem[] = [
  {
    name: 'पुणे',
    talukas: [
      {
        name: 'हवेली',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र कोंढवा',
            subCenters: [
              {
                name: 'उपकेंद्र कोंडापूर',
                villages: ['कोंडापूर', 'येवलेवाडी', 'पिसोळी', 'मांगडेवाडी'],
              },
              {
                name: 'उपकेंद्र उंद्री',
                villages: ['उंद्री', 'होळकरवाडी', 'वडाचीवाडी', 'हांडेवाडी'],
              },
              {
                name: 'उपकेंद्र आंबेगाव',
                villages: ['आंबेगाव बुद्रुक', 'आंबेगाव खुर्द', 'जांभूळवाडी', 'दत्तनगर'],
              },
              {
                name: 'उपकेंद्र धायरी',
                villages: ['धायरी', 'नऱ्हे', 'वडगाव बुद्रुक'],
              },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र वाघोली',
            subCenters: [
              {
                name: 'उपकेंद्र वाघोली',
                villages: ['वाघोली', 'बाकोरी', 'भावडी'],
              },
              {
                name: 'उपकेंद्र लोणीकंद',
                villages: ['लोणीकंद', 'पेरणे', 'फुलगाव'],
              },
              {
                name: 'उपकेंद्र कोलवडी',
                villages: ['कोलवडी', 'थेऊर', 'कदमवाकवस्ती'],
              },
              {
                name: 'उपकेंद्र केसनंद',
                villages: ['केसनंद', 'रांजणगाव सांडस', 'आव्हाळवाडी'],
              },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र उरुळी कांचन',
            subCenters: [
              {
                name: 'उपकेंद्र उरुळी कांचन',
                villages: ['उरुळी कांचन', 'कोरेगाव मूळ', 'आळंदी म्हातोबाची'],
              },
              {
                name: 'उपकेंद्र शिंदवणे',
                villages: ['शिंदवणे', 'सोरतापवाडी', 'भवरापूर'],
              },
              {
                name: 'उपकेंद्र कुंजीरवाडी',
                villages: ['कुंजीरवाडी', 'नायगाव', 'तरडे'],
              },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र खडकवासला',
            subCenters: [
              {
                name: 'उपकेंद्र खडकवासला',
                villages: ['खडकवासला', 'किरकटवाडी', 'नांदेडगाव'],
              },
              {
                name: 'उपकेंद्र खानापूर',
                villages: ['खानापूर', 'डोणजे', 'गोऱ्हे बुद्रुक', 'गोऱ्हे खुर्द'],
              },
            ],
          },
        ],
      },
      {
        name: 'बारामती',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र माळेगाव',
            subCenters: [
              {
                name: 'उपकेंद्र माळेगाव',
                villages: ['माळेगाव बुद्रुक', 'माळेगाव खुर्द', 'पाहुणेवाडी'],
              },
              {
                name: 'उपकेंद्र पणदरे',
                villages: ['पणदरे', 'कोरोची', 'काऱ्हाटी', 'शिरवली'],
              },
              {
                name: 'उपकेंद्र ढाकाळे',
                villages: ['ढाकाळे', 'गुणवडी', 'मुकदमवाडी'],
              },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र सुपा',
            subCenters: [
              {
                name: 'उपकेंद्र सुपा',
                villages: ['सुपा', 'देऊळगाव रसाळ', 'मोरगाव', 'तरडोली'],
              },
              {
                name: 'उपकेंद्र वडगाव निंबाळकर',
                villages: ['वडगाव निंबाळकर', 'कोराळे बुद्रुक', 'कऱ्हावागज'],
              },
            ],
          },
        ],
      },
      {
        name: 'शिरूर',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र शिक्रापूर',
            subCenters: [
              {
                name: 'उपकेंद्र शिक्रापूर',
                villages: ['शिक्रापूर', 'सणसवाडी', 'पिंपळे जगताप'],
              },
              {
                name: 'उपकेंद्र कोरेगाव भीमा',
                villages: ['कोरेगाव भीमा', 'डिंग्रजवाडी', 'जातेगाव'],
              },
              {
                name: 'उपकेंद्र तळेगाव ढमढेरे',
                villages: ['तळेगाव ढमढेरे', 'धामारी', 'रांजणगाव गणपती'],
              },
            ],
          },
          {
            name: 'प्रा.आ. केंद्र मांडवगण फराटा',
            subCenters: [
              {
                name: 'उपकेंद्र मांडवगण फराटा',
                villages: ['मांडवगण फराटा', 'तांदळी', 'इनामगाव'],
              },
              {
                name: 'उपकेंद्र शिरसगाव काटा',
                villages: ['शिरसगाव काटा', 'वडगाव रासाई', 'कुरुळी'],
              },
            ],
          },
        ],
      },
      {
        name: 'मुळशी',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र पौड',
            subCenters: [
              {
                name: 'उपकेंद्र पिरंगुट',
                villages: ['पिरंगुट', 'कासारआंबोली', 'उरवडे', 'घोटवडे'],
              },
              {
                name: 'उपकेंद्र पौड',
                villages: ['पौड', 'लवळे', 'नांदे', 'माण'],
              },
              {
                name: 'उपकेंद्र घोटावडे',
                villages: ['घोटावडे', 'मुगाव', 'रिहे'],
              },
            ],
          },
        ],
      },
      {
        name: 'खेड (राजगुरुनगर)',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र चाकण',
            subCenters: [
              {
                name: 'उपकेंद्र चाकण',
                villages: ['चाकण', 'मेदनकरवाडी', 'खराबवाडी', 'नाणेकरवाडी'],
              },
              {
                name: 'उपकेंद्र महाळुंगे',
                villages: ['महाळुंगे', 'इंगळे', 'कुरुळी'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: 'सातारा',
    talukas: [
      {
        name: 'सातारा',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र कोडोली',
            subCenters: [
              {
                name: 'उपकेंद्र कोडोली',
                villages: ['कोडोली', 'वडूथ', 'अरे'],
              },
              {
                name: 'उपकेंद्र शेंद्रे',
                villages: ['शेंद्रे', 'नागठाणे', 'बोर्गाव'],
              },
            ],
          },
        ],
      },
      {
        name: 'वाई',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र भुईंज',
            subCenters: [
              {
                name: 'उपकेंद्र भुईंज',
                villages: ['भुईंज', 'पाचवड', 'किकली'],
              },
              {
                name: 'उपकेंद्र सुरूर',
                villages: ['सुरूर', 'वेळे', 'ओझर्डे'],
              },
            ],
          },
        ],
      },
      {
        name: 'कराड',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र कोळे',
            subCenters: [
              {
                name: 'उपकेंद्र कोळे',
                villages: ['कोळे', 'ओंड', 'येळगाव'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: 'नाशिक',
    talukas: [
      {
        name: 'निफाड',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र पिंपळगाव बसवंत',
            subCenters: [
              {
                name: 'उपकेंद्र पिंपळगाव',
                villages: ['पिंपळगाव बसवंत', 'शिरवाडे', 'उंबरखेड'],
              },
            ],
          },
        ],
      },
      {
        name: 'दिंडोरी',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र वणी',
            subCenters: [
              {
                name: 'उपकेंद्र वणी',
                villages: ['वणी', 'महाजे', 'खतवड'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: 'अहमदनगर',
    talukas: [
      {
        name: 'संगमनेर',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र आश्वी बुद्रुक',
            subCenters: [
              {
                name: 'उपकेंद्र आश्वी',
                villages: ['आश्वी बुद्रुक', 'आश्वी खुर्द', 'उंबरी'],
              },
            ],
          },
        ],
      },
      {
        name: 'राहाता',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र शिर्डी',
            subCenters: [
              {
                name: 'उपकेंद्र शिर्डी ग्रामीण',
                villages: ['सावळिविहीर', 'रुई', 'निघोज'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: 'छत्रपती संभाजीनगर',
    talukas: [
      {
        name: 'पैठण',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र बिडकीन',
            subCenters: [
              {
                name: 'उपकेंद्र बिडकीन',
                villages: ['बिडकीन', 'निलजगाव', 'इसारवाडी'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: 'ठाणे',
    talukas: [
      {
        name: 'मुरबाड',
        phcs: [
          {
            name: 'प्रा.आ. केंद्र शिवळे',
            subCenters: [
              {
                name: 'उपकेंद्र शिवळे',
                villages: ['शिवळे', 'म्हसा', 'टोकावडे'],
              },
            ],
          },
        ],
      },
    ],
  },
];

// Helper functions
export function getDistricts(): string[] {
  return HEALTH_JURISDICTION_DATA.map((d) => d.name);
}

export function getTalukas(districtName: string): string[] {
  const d = HEALTH_JURISDICTION_DATA.find((item) => item.name === districtName);
  return d ? d.talukas.map((t) => t.name) : [];
}

export function getPhcs(districtName: string, talukaName: string): string[] {
  const d = HEALTH_JURISDICTION_DATA.find((item) => item.name === districtName);
  if (!d) return [];
  const t = d.talukas.find((item) => item.name === talukaName);
  return t ? t.phcs.map((p) => p.name) : [];
}

export function getSubCenters(
  districtName: string,
  talukaName: string,
  phcName: string
): string[] {
  const d = HEALTH_JURISDICTION_DATA.find((item) => item.name === districtName);
  if (!d) return [];
  const t = d.talukas.find((item) => item.name === talukaName);
  if (!t) return [];
  const p = t.phcs.find((item) => item.name === phcName);
  return p ? p.subCenters.map((s) => s.name) : [];
}

export function getVillages(
  districtName: string,
  talukaName: string,
  phcName: string,
  subCenterName: string
): string[] {
  const d = HEALTH_JURISDICTION_DATA.find((item) => item.name === districtName);
  if (!d) return [];
  const t = d.talukas.find((item) => item.name === talukaName);
  if (!t) return [];
  const p = t.phcs.find((item) => item.name === phcName);
  if (!p) return [];
  const s = p.subCenters.find((item) => item.name === subCenterName);
  return s ? s.villages : [];
}
